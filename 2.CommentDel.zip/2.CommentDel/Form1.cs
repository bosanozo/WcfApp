﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Xml;
using System.Text.RegularExpressions;

namespace CommentDel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// CommentDel
        /// </summary>
        private void CommentDel(string fname)
        {
            using (StreamWriter writer = new StreamWriter(fname, false, Encoding.Default))
            using (StreamReader reader = new StreamReader(fname + ".bak", Encoding.Default))
            {
                string line;
                int prevlen = 0;
                bool cblock = false;
                bool codeline = false;
                int linecnt = 0;
                StringBuilder sb = new StringBuilder();

                // コメント行出力
                Action writeCommentLine = () =>
                {
                    if (!codeline || linecnt <= 15) writer.Write(sb);
                    sb.Length = 0;
                    codeline = false;
                    linecnt = 0;
                };
                
                // 一行ずつ読み込み
                while ((line = reader.ReadLine()) != null)
                {
                    /*
                    line = line.TrimEnd();

                    // タブスペース化
                    Match m = Regex.Match(line, @"^\s+");
                    if (m.Success) line = m.Value.Replace("\t", "    ").Replace("　", "  ") + line.TrimStart();
                     */

                    // コメントブロックでない場合
                    if (!cblock)
                    {
                        // コメント行
                        if (Regex.IsMatch(line, @"^\s*//"))
                        {
                            if (Regex.IsMatch(line, "[;{}]$")) codeline = true;
                            sb.AppendLine(line);
                            linecnt++;
                        }
                        // コメントブロック開始
                        else if (Regex.IsMatch(line, @"^\s*/[*]")) cblock = true;
                        // 通常行
                        else
                        {
                            // コメント行出力
                            if (sb.Length > 0) writeCommentLine();

                            // 不要空白削除
                            line = Regex.Replace(line, @"\s+;$", ";");
                            line = Regex.Replace(line, @"\s+([+!<>=]?=)\s+", @" $1 ");

                            // 通常の場合
                            if (prevlen > 0 || line.Length > 0)
                                writer.WriteLine(line);
                            prevlen = line.Length;
                        }
                    }

                    // コメントブロックの場合
                    if (cblock)
                    {
                        sb.AppendLine(line);
                        linecnt++;
                        if (Regex.IsMatch(line, "[;{}]$")) codeline = true;

                        // コメントブロック終了
                        if (Regex.IsMatch(line, @"[*]/$"))
                        {
                            // コメント行出力
                            writeCommentLine();
                            cblock = false;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// ボタン押下
        /// </summary>
        private void button1_Click(object sender, EventArgs e)
        {
            foreach (string fname in Directory.GetFiles(textBox1.Text, "*.cs", SearchOption.AllDirectories))
            {
                if (File.Exists(fname + ".bak")) continue;
                File.Move(fname, fname + ".bak");

                label1.Text = Path.GetFileName(fname);
                CommentDel(fname);
            }

            MessageBox.Show("完了");
        }
    }
}
