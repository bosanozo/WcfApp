﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Drawing.Design;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace WindowsFormsApplication1
{
    [Designer(typeof(MyPanelDesigner))]
    public class MyPanel : UserControl // Panel
    {
        private Button button1;

        [DesignOnly(true)]
        [Editor(typeof(MyFileNameEditor), typeof(UITypeEditor))]
        [DefaultValue(null)]
        public string FileName { get; set; }

        [DesignOnly(true)]
        [DefaultValue(null)]
        public string SheetName { get; set; }

        [DesignOnly(true)]
        [DefaultValue(1)]
        public int ColumnCount { get; set; }

        public MyPanel()
        {
            InitializeComponent();
            ColumnCount = 1;
        }

        protected override void InitLayout()
        {
            base.InitLayout();

            if (DesignMode)
            {
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("aaa");
        }

        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(4, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MyPanel
            // 
            this.Controls.Add(this.button1);
            this.Name = "MyPanel";
            this.ResumeLayout(false);

        }
    }
}
