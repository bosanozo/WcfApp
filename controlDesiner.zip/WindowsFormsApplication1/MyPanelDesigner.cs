﻿#define ExcelDataReader

using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

using System.ComponentModel;
using System.ComponentModel.Design;
using System.Drawing.Design;
using System.Windows.Forms;
using System.Windows.Forms.Design;

using System.Reflection;

using Excel;
using LinqToExcel;

namespace WindowsFormsApplication1
{
    internal class MyPanelDesigner : ParentControlDesigner
    {
        public MyPanelDesigner()
        {
        }

        public override void Initialize(IComponent component)
        {
            base.Initialize(component);

            // スマートタグ追加
            ActionLists.Add(new MyDesignerActionList(component));
        }
    }

    // スマートタグ
    public class MyDesignerActionList : DesignerActionList
    {
        private MyPanel m_panel;

        [Editor(typeof(MyFileNameEditor), typeof(UITypeEditor))]
        public string FileName
        {
            get { return m_panel.FileName; }
            set { m_panel.FileName = value; }
        }

        public string SheetName
        {
            get { return m_panel.SheetName; }
            set { m_panel.SheetName = value; }
        }

        public int ColumnCount
        {
            get { return m_panel.ColumnCount; }
            set { m_panel.ColumnCount = value; }
        }

        public MyDesignerActionList(IComponent component) : base(component)
        {
            m_panel = (MyPanel)component;
        }

        public override DesignerActionItemCollection GetSortedActionItems()
        {
            DesignerActionItemCollection items = new DesignerActionItemCollection();

            //Define static section header entries.
            items.Add(new DesignerActionHeaderItem("Appearance"));

            items.Add(new DesignerActionPropertyItem("FileName", "ファイル名(.xlsx)", "Appearance", "項目定義"));
            items.Add(new DesignerActionPropertyItem("SheetName", "シート", "Appearance", "シート"));
            items.Add(new DesignerActionPropertyItem("ColumnCount", "列数", "Appearance"));

            items.Add(new DesignerActionMethodItem(this, "AddControl", "AddControl実行", "Appearance", true));
            return items;
        }

        /// <summary>
        /// コントロールを追加します。
        /// </summary>
        private void AddControl()
        {
            try
            {
#if ExcelDataReader
                DataTable table = null;
                using (var sr = File.OpenRead(FileName))
                using (var er = ExcelReaderFactory.CreateOpenXmlReader(sr))
                {
                    er.IsFirstRowAsColumnNames = true;
                    var result = er.AsDataSet();
                    table = result.Tables[0];
                }
#else
                LinqToExcel.Query.ExcelQueryable<Row> sheet;
                using (var excel = new ExcelQueryFactory(FileName))
                {
                    excel.ReadOnly = true;
                    //excel.DatabaseEngine = LinqToExcel.Domain.DatabaseEngine.Ace;
                    //comboBoxSheet.DataSource = excel.GetWorksheetNames();
                    sheet = excel.Worksheet("Sheet1");
                }
#endif

                var host = GetService(typeof(IDesignerHost)) as IDesignerHost;

                using (var tran = host.CreateTransaction("AddControl"))
                {
                    try
                    {
                        m_panel.SuspendLayout();

                        // 子コントロールをクリア
                        while (m_panel.Controls.Count > 0)
                            host.DestroyComponent(m_panel.Controls[0]);

                        // テーブルレイアウトパネルを作成
                        var tbPanel = host.CreateComponent(typeof(TableLayoutPanel)) as TableLayoutPanel;
                        tbPanel.Dock = DockStyle.Fill;
                        tbPanel.ColumnStyles.Clear();
                        for (int i = 0; i < ColumnCount * 2; i++)
                            tbPanel.ColumnStyles.Add(new ColumnStyle());
                        tbPanel.ColumnCount = tbPanel.ColumnStyles.Count;
                        tbPanel.RowStyles.Clear();

                        string prevName = null;
                        FlowLayoutPanel panel = null;
                        int colIdx = ColumnCount - 1;
#if ExcelDataReader
                        foreach(DataRow row in table.Rows)
#else
                        foreach (var row in sheet)
#endif
                        {
                            bool sameRow = prevName == row[0].ToString();
                            if (!sameRow)
                            {
                                // 列数が最大の場合は次の行に折り返し
                                if (colIdx >= ColumnCount - 1)
                                {
                                    colIdx = 0;
                                    tbPanel.RowStyles.Add(new RowStyle());
                                }
                                else colIdx++;

                                // ラベル
                                var label = host.CreateComponent(typeof(Label)) as Label;
                                label.Text = prevName = row[0].ToString();
                                label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                                tbPanel.Controls.Add(label, colIdx * 2, tbPanel.RowStyles.Count - 1);

                                // パネル
                                panel = host.CreateComponent(typeof(FlowLayoutPanel)) as FlowLayoutPanel;
                                panel.AutoSize = true;
                                panel.Dock = DockStyle.Fill;
                                tbPanel.Controls.Add(panel, colIdx * 2 + 1, tbPanel.RowStyles.Count - 1);

                                int colspan;
                                if (row["ColSpan"] != DBNull.Value && (colspan = Convert.ToInt32(row["ColSpan"])) > 1)
                                {
                                    if (colspan > ColumnCount - colIdx) colspan = ColumnCount - colIdx; 
                                    tbPanel.SetColumnSpan(panel, colspan * 2 - 1);
                                    colIdx += colspan - 1;
                                }
                            }

                            // コントロール
                            var controlType = Type.GetType("System.Windows.Forms." + row[2].ToString());
                            var control = host.CreateComponent(controlType) as Control;
                            var text = row["Text"].ToString();
                            if (text.Length > 0) control.Text = text;
                            if (control is TextBox)
                            {
                                int len;
                                if (row[3] != DBNull.Value && (len = Convert.ToInt32(row[3])) > 0)
                                    (control as TextBox).MaxLength = len;
                            }
                            panel.Controls.Add(control);
                        }

                        tbPanel.RowCount = tbPanel.RowStyles.Count;
                        m_panel.Controls.Add(tbPanel);
                        tran.Commit();
                    }
                    catch
                    {
                        tran.Cancel();
                        throw;
                    }
                    finally
                    {
                        m_panel.ResumeLayout();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
