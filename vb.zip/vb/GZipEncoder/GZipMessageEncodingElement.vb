Imports System.Xml
Imports System.ServiceModel
Imports System.Configuration
Imports System.ServiceModel.Channels
Imports System.ServiceModel.Configuration
Imports System.ServiceModel.Description

'This class is necessary to be able to plug in the GZip encoder binding element through
'a configuration file
Public Class GZipMessageEncodingElement
	Inherits BindingElementExtensionElement
	Public Sub New()
	End Sub

	'Called by the WCF to discover the type of binding element this config section enables
	Public Overrides ReadOnly Property BindingElementType() As Type
		Get
			Return GetType(GZipMessageEncodingBindingElement)
		End Get
	End Property

	'The only property we need to configure for our binding element is the type of
	'inner encoder to use. Here, we support text and binary.
	<ConfigurationProperty("innerMessageEncoding", DefaultValue := "textMessageEncoding")> _
	Public Property InnerMessageEncoding() As String
		Get
			Return DirectCast(MyBase.Item("innerMessageEncoding"), String)
		End Get
		Set
			MyBase.Item("innerMessageEncoding") = value
		End Set
	End Property

	'Called by the WCF to apply the configuration settings (the property above) to the binding element
	Public Overrides Sub ApplyConfiguration(bindingElement As BindingElement)
		Dim binding As GZipMessageEncodingBindingElement = DirectCast(bindingElement, GZipMessageEncodingBindingElement)
		Dim propertyInfo As PropertyInformationCollection = Me.ElementInformation.Properties
		If propertyInfo("innerMessageEncoding").ValueOrigin <> PropertyValueOrigin.[Default] Then
			Select Case Me.InnerMessageEncoding
				Case "textMessageEncoding"
					binding.InnerMessageEncodingBindingElement = New TextMessageEncodingBindingElement()
					Exit Select
				Case "binaryMessageEncoding"
					binding.InnerMessageEncodingBindingElement = New BinaryMessageEncodingBindingElement()
					Exit Select
			End Select
		End If
	End Sub

	'Called by the WCF to create the binding element
	Protected Overrides Function CreateBindingElement() As BindingElement
		Dim bindingElement As New GZipMessageEncodingBindingElement()
		Me.ApplyConfiguration(bindingElement)
		Return bindingElement
	End Function
End Class
