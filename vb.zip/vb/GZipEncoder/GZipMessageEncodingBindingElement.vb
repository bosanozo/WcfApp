
Imports System.Xml
Imports System.ServiceModel
Imports System.Configuration
Imports System.ServiceModel.Channels
Imports System.ServiceModel.Configuration
Imports System.ServiceModel.Description


'This is the binding element that, when plugged into a custom binding, will enable the GZip encoder
Public NotInheritable Class GZipMessageEncodingBindingElement
	Inherits MessageEncodingBindingElement
	'BindingElement
	', IPolicyExportExtension

	'We will use an inner binding element to store information required for the inner encoder
	Private innerBindingElement As MessageEncodingBindingElement

	'By default, use the default text encoder as the inner encoder
	Public Sub New()
		Me.New(New TextMessageEncodingBindingElement())
	End Sub

	Public Sub New(messageEncoderBindingElement As MessageEncodingBindingElement)
		Me.innerBindingElement = messageEncoderBindingElement
	End Sub

	Public Property InnerMessageEncodingBindingElement() As MessageEncodingBindingElement
		Get
			Return innerBindingElement
		End Get
		Set
			innerBindingElement = value
		End Set
	End Property

	'Main entry point into the encoder binding element. Called by WCF to get the factory that will create the
	'message encoder
	Public Overrides Function CreateMessageEncoderFactory() As MessageEncoderFactory
		Return New GZipMessageEncoderFactory(innerBindingElement.CreateMessageEncoderFactory())
	End Function

	Public Overrides Property MessageVersion() As MessageVersion
		Get
			Return innerBindingElement.MessageVersion
		End Get
		Set
			innerBindingElement.MessageVersion = value
		End Set
	End Property

	Public Overrides Function Clone() As BindingElement
		Return New GZipMessageEncodingBindingElement(Me.innerBindingElement)
	End Function

	Public Overrides Function GetProperty(Of T)(context As BindingContext) As T
		If GetType(T) = GetType(XmlDictionaryReaderQuotas) Then
			Return innerBindingElement.GetProperty(Of T)(context)
		Else
			Return MyBase.GetProperty(Of T)(context)
		End If
	End Function

	Public Overrides Function BuildChannelFactory(Of TChannel)(context As BindingContext) As IChannelFactory(Of TChannel)
		If context Is Nothing Then
			Throw New ArgumentNullException("context")
		End If

		context.BindingParameters.Add(Me)
		Return context.BuildInnerChannelFactory(Of TChannel)()
	End Function

	Public Overrides Function BuildChannelListener(Of TChannel)(context As BindingContext) As IChannelListener(Of TChannel)
		If context Is Nothing Then
			Throw New ArgumentNullException("context")
		End If

		context.BindingParameters.Add(Me)
		Return context.BuildInnerChannelListener(Of TChannel)()
	End Function

	Public Overrides Function CanBuildChannelListener(Of TChannel)(context As BindingContext) As Boolean
		If context Is Nothing Then
			Throw New ArgumentNullException("context")
		End If

		context.BindingParameters.Add(Me)
		Return context.CanBuildInnerChannelListener(Of TChannel)()
	End Function

	'
'        void IPolicyExportExtension.ExportPolicy(MetadataExporter exporter, PolicyConversionContext policyContext)
'        {
'            if (policyContext == null)
'            {
'                throw new ArgumentNullException("policyContext");
'            }
'            XmlDocument document = new XmlDocument();
'            policyContext.GetBindingAssertions().Add(document.CreateElement(
'                GZipMessageEncodingPolicyConstants.GZipEncodingPrefix,
'                GZipMessageEncodingPolicyConstants.GZipEncodingName,
'                GZipMessageEncodingPolicyConstants.GZipEncodingNamespace));
'        }

End Class
