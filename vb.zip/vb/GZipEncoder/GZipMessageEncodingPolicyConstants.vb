Imports System.Xml
Imports System.ServiceModel
Imports System.Configuration
Imports System.ServiceModel.Channels
Imports System.ServiceModel.Configuration
Imports System.ServiceModel.Description


' This is constants for GZip message encoding policy.
NotInheritable Class GZipMessageEncodingPolicyConstants
	Private Sub New()
	End Sub
	Public Const GZipEncodingName As String = "GZipEncoding"
	Public Const GZipEncodingNamespace As String = "http://schemas.microsoft.com/ws/06/2004/mspolicy/netgzip1"
	Public Const GZipEncodingPrefix As String = "gzip"
End Class
