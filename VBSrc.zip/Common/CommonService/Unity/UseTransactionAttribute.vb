

Imports Microsoft.Practices.Unity
Imports Microsoft.Practices.Unity.InterceptionExtension

Namespace Common.Unity
	''' <summary>
	''' トランザクションを設定するメソッドにつけるAttribute
	''' </summary>
	<AttributeUsage(AttributeTargets.Method)> _
	Public Class UseTransactionAttribute
		Inherits HandlerAttribute
		''' <summary>
		''' TransactionHandlerを作成する。
		''' </summary>
		''' <param name="container">IUnityContainer</param>
		''' <returns>TransactionHandler</returns>
		Public Overrides Function CreateHandler(container As IUnityContainer) As ICallHandler
			Return New TransactionHandler()
		End Function
	End Class
End Namespace

