
Imports System.Transactions
Imports Microsoft.Practices.Unity.InterceptionExtension

Namespace Common.Unity
	''' <summary>
	''' トランザクションを設定する。
	''' </summary>
	Public Class TransactionHandler
		Implements ICallHandler
		''' <summary>
		''' Order
		''' </summary>
		Public Property Order() As Integer
			Get
				Return m_Order
			End Get
			Set
				m_Order = Value
			End Set
		End Property
		Private m_Order As Integer

		''' <summary>
		''' メソッドをTransactionScope内で実行する。
		''' </summary>
		''' <param name="input">IMethodInvocation</param>
		''' <param name="getNext">GetNextHandlerDelegate</param>
		''' <returns>IMethodReturn</returns>
		Public Function Invoke(input As IMethodInvocation, getNext As GetNextHandlerDelegate) As IMethodReturn
			Dim returnMessage As IMethodReturn

			Using scope As New TransactionScope()
				'Use logging in production
				returnMessage = getNext()(input, getNext)
				'If Exception is thrown rollback
				If returnMessage.Exception Is Nothing Then
					scope.Complete()
				End If
			End Using

			Return returnMessage
		End Function
	End Class
End Namespace

