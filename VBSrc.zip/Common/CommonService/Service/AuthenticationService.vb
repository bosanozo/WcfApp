
Imports System.Collections.Generic
Imports System.Data
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks

Imports Common.DataAccess
Imports Common.Unity

Namespace Common.Service
	''' <summary>
	''' 共通処理サービス
	''' </summary>
	Public Class AuthenticationService
		Implements IAuthenticationService
		#Region "private変数"
		Private m_dataAccess As CommonDA
		#End Region

		#Region "コンストラクタ"
		''' <summary>
		''' コンストラクタ
		''' </summary>
		''' <param name="argDataAccess">データアクセス層インスタンス</param>
		Public Sub New(argDataAccess As CommonDA)
			m_dataAccess = argDataAccess
		End Sub
		#End Region

		#Region "サービスインターフェース実装"
		Public Function ValidateUser(username As String, password As String, customCredential As String) As Boolean
			Throw New NotImplementedException()
		End Function

		''' <summary>
		''' ログイン処理を行う。
		''' </summary>
		''' <param name="argUserName">ユーザID</param>
		''' <param name="argPassword">パスワード</param>
		''' <returns>true:成功, false:失敗</returns>
		Public Function Login(username As String, password As String, customCredential As String, isPersistent As Boolean) As Boolean
			Return m_dataAccess.Login(username, password)
		End Function

		Public Function IsLoggedIn() As Boolean
			Throw New NotImplementedException()
		End Function

		Public Sub Logout()
			Throw New NotImplementedException()
		End Sub
		#End Region
	End Class
End Namespace

