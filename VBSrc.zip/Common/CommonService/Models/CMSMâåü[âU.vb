
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema

Namespace Common.Models
	''' <summary>
	''' CMSMユーザ
	''' </summary>
	<Serializable> _
	Public Class CMSMユーザ
		Implements IHasUpdateInfo
		''' <summary>コンストラクタ</summary>
		Public Sub New()
			UpdateInfo = New UpdateInfo()
		End Sub

		''' <summary>ユーザID</summary>
		<Key> _
		<Column(Order := 1)> _
		Public Property ユーザID() As String
			Get
				Return m_ユーザID
			End Get
			Set
				m_ユーザID = Value
			End Set
		End Property
		Private m_ユーザID As String

		''' <summary>ユーザ名</summary>
		<Required> _
		Public Property ユーザ名() As String
			Get
				Return m_ユーザ名
			End Get
			Set
				m_ユーザ名 = Value
			End Set
		End Property
		Private m_ユーザ名 As String

		''' <summary>パスワード</summary>
		<Required> _
		Public Property パスワード() As String
			Get
				Return m_パスワード
			End Get
			Set
				m_パスワード = Value
			End Set
		End Property
		Private m_パスワード As String

		''' <summary>メールアドレス</summary>
		Public Property メールアドレス() As String
			Get
				Return m_メールアドレス
			End Get
			Set
				m_メールアドレス = Value
			End Set
		End Property
		Private m_メールアドレス As String

		''' <summary>組織CD</summary>
		<Required> _
		Public Property 組織CD() As String
			Get
				Return m_組織CD
			End Get
			Set
				m_組織CD = Value
			End Set
		End Property
		Private m_組織CD As String

		''' <summary>共通項目（更新情報）</summary>
		Public Property UpdateInfo() As UpdateInfo
			Get
				Return m_UpdateInfo
			End Get
			Set
				m_UpdateInfo = Value
			End Set
		End Property
		Private m_UpdateInfo As UpdateInfo
	End Class
End Namespace

