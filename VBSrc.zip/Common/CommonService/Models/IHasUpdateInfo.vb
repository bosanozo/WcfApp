
' * 【共通部品】
' * 
' * 作成者: 豆蔵／田中 望
' * 改版履歴:
' * 2014.7.1, 新規作成

Namespace Common.Models
	''' <summary>
	''' テーブル共通項目（作成・更新情報）があることを示すインターフェース
	''' </summary>
	Public Interface IHasUpdateInfo
		Property UpdateInfo() As UpdateInfo
	End Interface
End Namespace

