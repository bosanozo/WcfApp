
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema

Namespace Common.Models
	''' <summary>
	''' CMSM汎用基準値
	''' </summary>
	<Serializable> _
	Public Class CMSM汎用基準値
		Implements IHasUpdateInfo
		''' <summary>コンストラクタ</summary>
		Public Sub New()
			UpdateInfo = New UpdateInfo()
		End Sub

		''' <summary>分類CD</summary>
		<Key> _
		<Column(Order := 1)> _
		Public Property 分類CD() As String
			Get
				Return m_分類CD
			End Get
			Set
				m_分類CD = Value
			End Set
		End Property
		Private m_分類CD As String

		''' <summary>基準値CD</summary>
		<Key> _
		<Column(Order := 2)> _
		Public Property 基準値CD() As String
			Get
				Return m_基準値CD
			End Get
			Set
				m_基準値CD = Value
			End Set
		End Property
		Private m_基準値CD As String

		''' <summary>分類名</summary>
		<Required> _
		Public Property 分類名() As String
			Get
				Return m_分類名
			End Get
			Set
				m_分類名 = Value
			End Set
		End Property
		Private m_分類名 As String

		''' <summary>基準値名</summary>
		<Required> _
		Public Property 基準値名() As String
			Get
				Return m_基準値名
			End Get
			Set
				m_基準値名 = Value
			End Set
		End Property
		Private m_基準値名 As String

		''' <summary>基準値1</summary>
		Public Property 基準値1() As System.Nullable(Of Decimal)
			Get
				Return m_基準値1
			End Get
			Set
				m_基準値1 = Value
			End Set
		End Property
		Private m_基準値1 As System.Nullable(Of Decimal)

		''' <summary>基準値2</summary>
		Public Property 基準値2() As System.Nullable(Of Decimal)
			Get
				Return m_基準値2
			End Get
			Set
				m_基準値2 = Value
			End Set
		End Property
		Private m_基準値2 As System.Nullable(Of Decimal)

		''' <summary>基準値3</summary>
		Public Property 基準値3() As System.Nullable(Of Decimal)
			Get
				Return m_基準値3
			End Get
			Set
				m_基準値3 = Value
			End Set
		End Property
		Private m_基準値3 As System.Nullable(Of Decimal)

		''' <summary>基準値4</summary>
		Public Property 基準値4() As System.Nullable(Of Decimal)
			Get
				Return m_基準値4
			End Get
			Set
				m_基準値4 = Value
			End Set
		End Property
		Private m_基準値4 As System.Nullable(Of Decimal)

		''' <summary>文字項目1</summary>
		Public Property 文字項目1() As String
			Get
				Return m_文字項目1
			End Get
			Set
				m_文字項目1 = Value
			End Set
		End Property
		Private m_文字項目1 As String

		''' <summary>文字項目2</summary>
		Public Property 文字項目2() As String
			Get
				Return m_文字項目2
			End Get
			Set
				m_文字項目2 = Value
			End Set
		End Property
		Private m_文字項目2 As String

		''' <summary>文字項目3</summary>
		Public Property 文字項目3() As String
			Get
				Return m_文字項目3
			End Get
			Set
				m_文字項目3 = Value
			End Set
		End Property
		Private m_文字項目3 As String

		''' <summary>文字項目4</summary>
		Public Property 文字項目4() As String
			Get
				Return m_文字項目4
			End Get
			Set
				m_文字項目4 = Value
			End Set
		End Property
		Private m_文字項目4 As String

		''' <summary>共通項目（更新情報）</summary>
		Public Property UpdateInfo() As UpdateInfo
			Get
				Return m_UpdateInfo
			End Get
			Set
				m_UpdateInfo = Value
			End Set
		End Property
		Private m_UpdateInfo As UpdateInfo
	End Class
End Namespace

