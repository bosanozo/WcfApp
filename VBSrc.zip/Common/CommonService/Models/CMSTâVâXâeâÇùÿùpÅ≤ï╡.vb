
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema

Namespace Common.Models
	''' <summary>
	''' CMSTシステム利用状況
	''' </summary>
	<Serializable> _
	Public Class CMSTシステム利用状況
		Implements IHasUpdateInfo
		''' <summary>コンストラクタ</summary>
		Public Sub New()
			UpdateInfo = New UpdateInfo()
		End Sub

		''' <summary>処理日時</summary>
		Public Property 処理日時() As DateTime
			Get
				Return m_処理日時
			End Get
			Set
				m_処理日時 = Value
			End Set
		End Property
		Private m_処理日時 As DateTime

		''' <summary>画面ID</summary>
		<Required> _
		Public Property 画面ID() As String
			Get
				Return m_画面ID
			End Get
			Set
				m_画面ID = Value
			End Set
		End Property
		Private m_画面ID As String

		''' <summary>画面名 </summary>
		Public Property 画面名() As String
			Get
				Return m_画面名
			End Get
			Set
				m_画面名 = Value
			End Set
		End Property
		Private m_画面名 As String

		''' <summary>ユーザID</summary>
		<Required> _
		Public Property ユーザID() As String
			Get
				Return m_ユーザID
			End Get
			Set
				m_ユーザID = Value
			End Set
		End Property
		Private m_ユーザID As String

		''' <summary>端末ID</summary>
		<Required> _
		Public Property 端末ID() As String
			Get
				Return m_端末ID
			End Get
			Set
				m_端末ID = Value
			End Set
		End Property
		Private m_端末ID As String

		''' <summary>APサーバ</summary>
		<Required> _
		Public Property APサーバ() As String
			Get
				Return m_APサーバ
			End Get
			Set
				m_APサーバ = Value
			End Set
		End Property
		Private m_APサーバ As String

		''' <summary>共通項目（更新情報）</summary>
		Public Property UpdateInfo() As UpdateInfo
			Get
				Return m_UpdateInfo
			End Get
			Set
				m_UpdateInfo = Value
			End Set
		End Property
		Private m_UpdateInfo As UpdateInfo
	End Class
End Namespace

