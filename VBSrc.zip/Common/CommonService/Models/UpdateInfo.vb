
' * 【共通部品】
' * 
' * 作成者: 豆蔵／田中 望
' * 改版履歴:
' * 2014.7.1, 新規作成

Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema

Namespace Common.Models
	''' <summary>
	''' テーブル共通項目（作成・更新情報）
	''' </summary>
	Public Class UpdateInfo
		<Column("作成日時")> _
		Public Property CreateDate() As DateTime
			Get
				Return m_CreateDate
			End Get
			Set
				m_CreateDate = Value
			End Set
		End Property
		Private m_CreateDate As DateTime

		<Column("作成者ID")> _
		Public Property CreateId() As String
			Get
				Return m_CreateId
			End Get
			Set
				m_CreateId = Value
			End Set
		End Property
		Private m_CreateId As String

		<Column("作成者IP")> _
		Public Property CreateHost() As String
			Get
				Return m_CreateHost
			End Get
			Set
				m_CreateHost = Value
			End Set
		End Property
		Private m_CreateHost As String

		<Column("作成PG")> _
		Public Property CreatePg() As String
			Get
				Return m_CreatePg
			End Get
			Set
				m_CreatePg = Value
			End Set
		End Property
		Private m_CreatePg As String

		<Column("更新日時")> _
		Public Property UpdateDate() As DateTime
			Get
				Return m_UpdateDate
			End Get
			Set
				m_UpdateDate = Value
			End Set
		End Property
		Private m_UpdateDate As DateTime

		<Column("更新者ID")> _
		Public Property UpdateId() As String
			Get
				Return m_UpdateId
			End Get
			Set
				m_UpdateId = Value
			End Set
		End Property
		Private m_UpdateId As String

		<Column("更新者IP")> _
		Public Property UpdateHost() As String
			Get
				Return m_UpdateHost
			End Get
			Set
				m_UpdateHost = Value
			End Set
		End Property
		Private m_UpdateHost As String

		<Column("更新PG")> _
		Public Property UpdatePg() As String
			Get
				Return m_UpdatePg
			End Get
			Set
				m_UpdatePg = Value
			End Set
		End Property
		Private m_UpdatePg As String

		<Timestamp> _
		<Column("排他用バージョン")> _
		Public Property Version() As Byte()
			Get
				Return m_Version
			End Get
			Set
				m_Version = Value
			End Set
		End Property
		Private m_Version As Byte()

		<NotMapped> _
		Public Property RowNumber() As Integer
			Get
				Return m_RowNumber
			End Get
			Set
				m_RowNumber = Value
			End Set
		End Property
		Private m_RowNumber As Integer
	End Class
End Namespace

