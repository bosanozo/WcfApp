
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema

Namespace Common.Models
	''' <summary>
	''' CMSM業務日付
	''' </summary>
	<Serializable> _
	Public Class CMSM業務日付
		Implements IHasUpdateInfo
		''' <summary>コンストラクタ</summary>
		Public Sub New()
			UpdateInfo = New UpdateInfo()
		End Sub

		''' <summary>組織CD</summary>
		<Key> _
		<Column(Order := 1)> _
		Public Property 組織CD() As String
			Get
				Return m_組織CD
			End Get
			Set
				m_組織CD = Value
			End Set
		End Property
		Private m_組織CD As String

		''' <summary>差分日数</summary>
		Public Property 差分日数() As Integer
			Get
				Return m_差分日数
			End Get
			Set
				m_差分日数 = Value
			End Set
		End Property
		Private m_差分日数 As Integer

		''' <summary>切替時間</summary>
		<Required> _
		Public Property 切替時間() As String
			Get
				Return m_切替時間
			End Get
			Set
				m_切替時間 = Value
			End Set
		End Property
		Private m_切替時間 As String

		''' <summary>共通項目（更新情報）</summary>
		Public Property UpdateInfo() As UpdateInfo
			Get
				Return m_UpdateInfo
			End Get
			Set
				m_UpdateInfo = Value
			End Set
		End Property
		Private m_UpdateInfo As UpdateInfo
	End Class
End Namespace

