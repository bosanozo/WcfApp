
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema

Namespace Common.Models
	''' <summary>
	''' CMSTシステム情報
	''' </summary>
	<Serializable> _
	Public Class CMSTシステム情報
		Implements IHasUpdateInfo
		''' <summary>コンストラクタ</summary>
		Public Sub New()
			UpdateInfo = New UpdateInfo()
		End Sub

		''' <summary>記事NO</summary>
		<Key> _
		<Column(Order := 1)> _
		Public Property 記事NO() As Integer
			Get
				Return m_記事NO
			End Get
			Set
				m_記事NO = Value
			End Set
		End Property
		Private m_記事NO As Integer

		''' <summary>組織CD</summary>
		<Required> _
		Public Property 組織CD() As String
			Get
				Return m_組織CD
			End Get
			Set
				m_組織CD = Value
			End Set
		End Property
		Private m_組織CD As String

		''' <summary>重要度</summary>
		<Required> _
		Public Property 重要度() As String
			Get
				Return m_重要度
			End Get
			Set
				m_重要度 = Value
			End Set
		End Property
		Private m_重要度 As String

		''' <summary>内容</summary>
		Public Property 内容() As String
			Get
				Return m_内容
			End Get
			Set
				m_内容 = Value
			End Set
		End Property
		Private m_内容 As String

		''' <summary>表示期間From</summary>
		Public Property 表示期間From() As System.Nullable(Of DateTime)
			Get
				Return m_表示期間From
			End Get
			Set
				m_表示期間From = Value
			End Set
		End Property
		Private m_表示期間From As System.Nullable(Of DateTime)

		''' <summary>表示期間To</summary>
		Public Property 表示期間To() As System.Nullable(Of DateTime)
			Get
				Return m_表示期間To
			End Get
			Set
				m_表示期間To = Value
			End Set
		End Property
		Private m_表示期間To As System.Nullable(Of DateTime)

		''' <summary>共通項目（更新情報）</summary>
		Public Property UpdateInfo() As UpdateInfo
			Get
				Return m_UpdateInfo
			End Get
			Set
				m_UpdateInfo = Value
			End Set
		End Property
		Private m_UpdateInfo As UpdateInfo
	End Class
End Namespace

