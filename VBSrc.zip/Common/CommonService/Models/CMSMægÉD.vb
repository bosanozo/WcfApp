
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema

Namespace Common.Models
	''' <summary>
	''' CMSM組織
	''' </summary>
	<Serializable> _
	Public Class CMSM組織
		Implements IHasUpdateInfo
		''' <summary>コンストラクタ</summary>
		Public Sub New()
			UpdateInfo = New UpdateInfo()
		End Sub

		''' <summary>組織CD</summary>
		<Key> _
		<Column(Order := 1)> _
		Public Property 組織CD() As String
			Get
				Return m_組織CD
			End Get
			Set
				m_組織CD = Value
			End Set
		End Property
		Private m_組織CD As String

		''' <summary>組織名</summary>
		<Required> _
		Public Property 組織名() As String
			Get
				Return m_組織名
			End Get
			Set
				m_組織名 = Value
			End Set
		End Property
		Private m_組織名 As String

		''' <summary>組織階層区分</summary>
		<Required> _
		Public Property 組織階層区分() As String
			Get
				Return m_組織階層区分
			End Get
			Set
				m_組織階層区分 = Value
			End Set
		End Property
		Private m_組織階層区分 As String

		''' <summary>上位組織CD</summary>
		<Required> _
		Public Property 上位組織CD() As String
			Get
				Return m_上位組織CD
			End Get
			Set
				m_上位組織CD = Value
			End Set
		End Property
		Private m_上位組織CD As String

		''' <summary>共通項目（更新情報）</summary>
		Public Property UpdateInfo() As UpdateInfo
			Get
				Return m_UpdateInfo
			End Get
			Set
				m_UpdateInfo = Value
			End Set
		End Property
		Private m_UpdateInfo As UpdateInfo
	End Class
End Namespace

