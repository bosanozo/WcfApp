
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema

Namespace Common.Models
	''' <summary>
	''' CMSMメニュー
	''' </summary>
	<Serializable> _
	Public Class CMSMメニュー
		Implements IHasUpdateInfo
		''' <summary>コンストラクタ</summary>
		Public Sub New()
			UpdateInfo = New UpdateInfo()
		End Sub

		''' <summary>メニューID</summary>
		<Key> _
		<Column(Order := 1)> _
		Public Property メニューID() As String
			Get
				Return m_メニューID
			End Get
			Set
				m_メニューID = Value
			End Set
		End Property
		Private m_メニューID As String

		''' <summary>上位メニューID</summary>
		<Required> _
		Public Property 上位メニューID() As String
			Get
				Return m_上位メニューID
			End Get
			Set
				m_上位メニューID = Value
			End Set
		End Property
		Private m_上位メニューID As String

		''' <summary>画面名</summary>
		Public Property 画面名() As String
			Get
				Return m_画面名
			End Get
			Set
				m_画面名 = Value
			End Set
		End Property
		Private m_画面名 As String

		''' <summary>URL</summary>
		Public Property URL() As String
			Get
				Return m_URL
			End Get
			Set
				m_URL = Value
			End Set
		End Property
		Private m_URL As String

		''' <summary>オプション</summary>
		Public Property オプション() As String
			Get
				Return m_オプション
			End Get
			Set
				m_オプション = Value
			End Set
		End Property
		Private m_オプション As String

		''' <summary>空欄フラグ</summary>
		Public Property 空欄フラグ() As System.Nullable(Of Boolean)
			Get
				Return m_空欄フラグ
			End Get
			Set
				m_空欄フラグ = Value
			End Set
		End Property
		Private m_空欄フラグ As System.Nullable(Of Boolean)

		''' <summary>共通項目（更新情報）</summary>
		Public Property UpdateInfo() As UpdateInfo
			Get
				Return m_UpdateInfo
			End Get
			Set
				m_UpdateInfo = Value
			End Set
		End Property
		Private m_UpdateInfo As UpdateInfo
	End Class
End Namespace

