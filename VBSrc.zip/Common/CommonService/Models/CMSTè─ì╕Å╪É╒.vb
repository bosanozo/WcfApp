
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema

Namespace Common.Models
	''' <summary>
	''' CMST監査証跡
	''' </summary>
	<Serializable> _
	Public Class CMST監査証跡
		Implements IHasUpdateInfo
		''' <summary>コンストラクタ</summary>
		Public Sub New()
			UpdateInfo = New UpdateInfo()
		End Sub

		''' <summary>テーブル名</summary>
		Public Property テーブル名() As String
			Get
				Return m_テーブル名
			End Get
			Set
				m_テーブル名 = Value
			End Set
		End Property
		Private m_テーブル名 As String

		''' <summary>更新区分</summary>
		Public Property 更新区分() As String
			Get
				Return m_更新区分
			End Get
			Set
				m_更新区分 = Value
			End Set
		End Property
		Private m_更新区分 As String

		''' <summary>キー</summary>
		Public Property キー() As String
			Get
				Return m_キー
			End Get
			Set
				m_キー = Value
			End Set
		End Property
		Private m_キー As String

		''' <summary>内容</summary>
		Public Property 内容() As String
			Get
				Return m_内容
			End Get
			Set
				m_内容 = Value
			End Set
		End Property
		Private m_内容 As String

		''' <summary>共通項目（更新情報）</summary>
		Public Property UpdateInfo() As UpdateInfo
			Get
				Return m_UpdateInfo
			End Get
			Set
				m_UpdateInfo = Value
			End Set
		End Property
		Private m_UpdateInfo As UpdateInfo
	End Class
End Namespace

