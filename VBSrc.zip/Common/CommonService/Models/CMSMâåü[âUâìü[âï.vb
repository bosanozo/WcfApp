
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema

Namespace Common.Models
	''' <summary>
	''' CMSMユーザロール
	''' </summary>
	<Serializable> _
	Public Class CMSMユーザロール
		Implements IHasUpdateInfo
		''' <summary>コンストラクタ</summary>
		Public Sub New()
			UpdateInfo = New UpdateInfo()
		End Sub

		''' <summary>ユーザID</summary>
		<Key> _
		<Column(Order := 1)> _
		Public Property ユーザID() As String
			Get
				Return m_ユーザID
			End Get
			Set
				m_ユーザID = Value
			End Set
		End Property
		Private m_ユーザID As String

		''' <summary>ロールID</summary>
		<Key> _
		<Column(Order := 2)> _
		Public Property ロールID() As String
			Get
				Return m_ロールID
			End Get
			Set
				m_ロールID = Value
			End Set
		End Property
		Private m_ロールID As String

		''' <summary>共通項目（更新情報）</summary>
		Public Property UpdateInfo() As UpdateInfo
			Get
				Return m_UpdateInfo
			End Get
			Set
				m_UpdateInfo = Value
			End Set
		End Property
		Private m_UpdateInfo As UpdateInfo
	End Class
End Namespace

