
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema

Namespace Common.Models
	''' <summary>
	''' CMSM参照範囲
	''' </summary>
	<Serializable> _
	Public Class CMSM参照範囲
		Implements IHasUpdateInfo
		''' <summary>コンストラクタ</summary>
		Public Sub New()
			UpdateInfo = New UpdateInfo()
		End Sub

		''' <summary>組織CD</summary>
		<Key> _
		<Column(Order := 1)> _
		Public Property 組織CD() As String
			Get
				Return m_組織CD
			End Get
			Set
				m_組織CD = Value
			End Set
		End Property
		Private m_組織CD As String

		''' <summary>ロールID</summary>
		<Key> _
		<Column(Order := 2)> _
		Public Property ロールID() As String
			Get
				Return m_ロールID
			End Get
			Set
				m_ロールID = Value
			End Set
		End Property
		Private m_ロールID As String

		''' <summary>画面ID</summary>
		<Key> _
		<Column(Order := 3)> _
		Public Property 画面ID() As String
			Get
				Return m_画面ID
			End Get
			Set
				m_画面ID = Value
			End Set
		End Property
		Private m_画面ID As String

		''' <summary>許否フラグ</summary>
		Public Property 許否フラグ() As System.Nullable(Of Boolean)
			Get
				Return m_許否フラグ
			End Get
			Set
				m_許否フラグ = Value
			End Set
		End Property
		Private m_許否フラグ As System.Nullable(Of Boolean)

		''' <summary>共通項目（更新情報）</summary>
		Public Property UpdateInfo() As UpdateInfo
			Get
				Return m_UpdateInfo
			End Get
			Set
				m_UpdateInfo = Value
			End Set
		End Property
		Private m_UpdateInfo As UpdateInfo
	End Class
End Namespace

