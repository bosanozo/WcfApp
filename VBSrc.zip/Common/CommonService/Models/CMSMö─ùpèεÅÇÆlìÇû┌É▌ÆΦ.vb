
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema

Namespace Common.Models
	''' <summary>
	''' CMSM汎用基準値項目設定
	''' </summary>
	<Serializable> _
	Public Class CMSM汎用基準値項目設定
		Implements IHasUpdateInfo
		''' <summary>コンストラクタ</summary>
		Public Sub New()
			UpdateInfo = New UpdateInfo()
		End Sub

		''' <summary>組織別フラグ</summary>
		<Key> _
		<Column(Order := 1)> _
		Public Property 組織別フラグ() As Boolean
			Get
				Return m_組織別フラグ
			End Get
			Set
				m_組織別フラグ = Value
			End Set
		End Property
		Private m_組織別フラグ As Boolean

		''' <summary>分類CD</summary>
		<Key> _
		<Column(Order := 2)> _
		Public Property 分類CD() As String
			Get
				Return m_分類CD
			End Get
			Set
				m_分類CD = Value
			End Set
		End Property
		Private m_分類CD As String

		''' <summary>データ区分</summary>
		<Key> _
		<Column(Order := 3)> _
		Public Property データ区分() As String
			Get
				Return m_データ区分
			End Get
			Set
				m_データ区分 = Value
			End Set
		End Property
		Private m_データ区分 As String

		''' <summary>基準値NO</summary>
		<Key> _
		<Column(Order := 4)> _
		Public Property 基準値NO() As Integer
			Get
				Return m_基準値NO
			End Get
			Set
				m_基準値NO = Value
			End Set
		End Property
		Private m_基準値NO As Integer

		''' <summary>項目名</summary>
		<Required> _
		Public Property 項目名() As String
			Get
				Return m_項目名
			End Get
			Set
				m_項目名 = Value
			End Set
		End Property
		Private m_項目名 As String

		''' <summary>桁数</summary>
		Public Property 桁数() As Integer
			Get
				Return m_桁数
			End Get
			Set
				m_桁数 = Value
			End Set
		End Property
		Private m_桁数 As Integer

		''' <summary>必須フラグ</summary>
		Public Property 必須フラグ() As Boolean
			Get
				Return m_必須フラグ
			End Get
			Set
				m_必須フラグ = Value
			End Set
		End Property
		Private m_必須フラグ As Boolean

		''' <summary>ゼロ埋めフラグ</summary>
		Public Property ゼロ埋めフラグ() As Boolean
			Get
				Return m_ゼロ埋めフラグ
			End Get
			Set
				m_ゼロ埋めフラグ = Value
			End Set
		End Property
		Private m_ゼロ埋めフラグ As Boolean

		''' <summary>共通項目（更新情報）</summary>
		Public Property UpdateInfo() As UpdateInfo
			Get
				Return m_UpdateInfo
			End Get
			Set
				m_UpdateInfo = Value
			End Set
		End Property
		Private m_UpdateInfo As UpdateInfo
	End Class
End Namespace

