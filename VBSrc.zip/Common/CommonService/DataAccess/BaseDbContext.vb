
' * 【共通部品】
' * 
' * 作成者: 豆蔵／田中 望
' * 改版履歴:
' * 2014.7.1, 新規作成

Imports System.Collections.Generic
Imports System.Data.Entity
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks

Imports System.Data.Entity.Infrastructure
Imports System.Data.Entity.Validation

Imports log4net

Imports Common
Imports Common.Models

Namespace Common.DataAccess
	''' <summary>
	''' DbContextの基底クラス
	''' </summary>
	Public Class BaseDbContext
		Inherits DbContext
		#Region "ロガーフィールド"
		Private m_logger As ILog
		#End Region

		#Region "プロパティ"
		Public Overridable Property CMSMメニュー() As DbSet(Of CMSMメニュー)
			Get
				Return m_CMSMメニュー
			End Get
			Set
				m_CMSMメニュー = Value
			End Set
		End Property
		Private Overridable m_CMSMメニュー As DbSet(Of CMSMメニュー)
		Public Overridable Property CMSMユーザ() As DbSet(Of CMSMユーザ)
			Get
				Return m_CMSMユーザ
			End Get
			Set
				m_CMSMユーザ = Value
			End Set
		End Property
		Private Overridable m_CMSMユーザ As DbSet(Of CMSMユーザ)
		Public Overridable Property CMSMユーザロール() As DbSet(Of CMSMユーザロール)
			Get
				Return m_CMSMユーザロール
			End Get
			Set
				m_CMSMユーザロール = Value
			End Set
		End Property
		Private Overridable m_CMSMユーザロール As DbSet(Of CMSMユーザロール)
		Public Overridable Property CMSM組織() As DbSet(Of CMSM組織)
			Get
				Return m_CMSM組織
			End Get
			Set
				m_CMSM組織 = Value
			End Set
		End Property
		Private Overridable m_CMSM組織 As DbSet(Of CMSM組織)
		Public Overridable Property CMSM汎用基準値() As DbSet(Of CMSM汎用基準値)
			Get
				Return m_CMSM汎用基準値
			End Get
			Set
				m_CMSM汎用基準値 = Value
			End Set
		End Property
		Private Overridable m_CMSM汎用基準値 As DbSet(Of CMSM汎用基準値)
		#End Region

		''' <summary>PKEY制約違反エラーNO</summary>
		Private Const PKEY_ERR As Integer = 2627

		Private Const DB_ERR As String = "EV002"

		#Region "コンストラクタ"
		''' <summary>
		''' コンストラクタ
		''' </summary>
		Public Sub New()
			MyBase.New("Default")
			' ロガーを取得
			m_logger = LogManager.GetLogger(Me.[GetType]())
		End Sub
		#End Region

		#Region "overrideメソッド"
		''' <summary>
		''' 変更を永続化する。
		''' </summary>
		''' <returns></returns>
		Public Overrides Function SaveChanges() As Integer
			Dim changeDate As DateTime = DateTime.Now
			Dim changeSet = ChangeTracker.Entries(Of IHasUpdateInfo)()

			If changeSet IsNot Nothing Then
				For Each entry__1 As var In changeSet
					' 状態に応じて更新情報を設定する
					If entry__1.State = EntityState.Added OrElse entry__1.State = EntityState.Modified Then
						Dim updInfo = entry__1.Entity.UpdateInfo

						If entry__1.State = EntityState.Added Then
							updInfo.CreateDate = changeDate
							updInfo.CreatePg = InformationManager.ClientInfo.FormId
							updInfo.CreateHost = InformationManager.ClientInfo.HostName
							updInfo.CreateId = InformationManager.UserInfo.Id
						End If

						updInfo.UpdateDate = changeDate
						updInfo.UpdatePg = InformationManager.ClientInfo.FormId
						updInfo.UpdateHost = InformationManager.ClientInfo.HostName
						updInfo.UpdateId = InformationManager.UserInfo.Id
					End If
				Next
			End If

			Dim ret As Integer = 0

			Try
				ret = MyBase.SaveChanges()
			Catch e As DbUpdateConcurrencyException
				Dim message As ApplicationMessage

				Dim entity = e.Entries.First()

				If TypeOf entity.Entity Is IHasUpdateInfo Then
					' データベース値を検索
					Dim dbValues As DbPropertyValues = Entry(entity.Entity).GetDatabaseValues()

					If dbValues IsNot Nothing Then
						Dim updInfo As DbPropertyValues = DirectCast(dbValues("UpdateInfo"), DbPropertyValues)

						If entity.State = EntityState.Modified Then
							message = New ApplicationMessage("WV002", updInfo("UpdateId"), updInfo("UpdateDate"), updInfo("UpdatePg"), updInfo("UpdateHost"))
						ElseIf entity.State = EntityState.Deleted Then
							message = New ApplicationMessage("WV004", updInfo("UpdateId"), updInfo("UpdateDate"), updInfo("UpdatePg"), updInfo("UpdateHost"))
						Else
							message = New ApplicationMessage(DB_ERR, CommonUtil.GetExceptionMessage(e))
						End If
					Else
						If entity.State = EntityState.Modified Then
							message = New ApplicationMessage("WV003")
						ElseIf entity.State = EntityState.Deleted Then
							message = New ApplicationMessage("WV005")
						Else
							message = New ApplicationMessage(DB_ERR, CommonUtil.GetExceptionMessage(e))
						End If
					End If

					message.RowField = New RowField(entity.Entity.[GetType]().Name, DirectCast(entity.Entity, IHasUpdateInfo).UpdateInfo.RowNumber)
				Else
					message = New ApplicationMessage(DB_ERR, CommonUtil.GetExceptionMessage(e))
				End If

				Throw New BusinessException(message, e)
			Catch e As DbUpdateException
				Dim msgCd As String = DB_ERR
				Dim ex As Exception = e

				Dim innerEx = TryCast(e.InnerException.InnerException, System.Data.SqlClient.SqlException)

				If innerEx IsNot Nothing Then
					If innerEx.Number = PKEY_ERR Then
						msgCd = "WV001"
					End If
					ex = innerEx
				End If

				Dim entity As Object = e.Entries.First().Entity
				Dim rowField = New RowField(entity.[GetType]().Name, DirectCast(entity, IHasUpdateInfo).UpdateInfo.RowNumber)

				Dim message = New ApplicationMessage(msgCd, rowField, CommonUtil.GetExceptionMessage(ex))
				Throw New BusinessException(message, ex)
			Catch e As DbEntityValidationException
				Dim sb As New StringBuilder()
				For Each err As var In e.EntityValidationErrors
					Dim verr = err.ValidationErrors.First()
					sb.AppendFormat("{0}:{1}", err.Entry.Entity.[GetType]().Name, verr.ErrorMessage)
				Next

				Dim entity As Object = e.EntityValidationErrors.First().Entry.Entity
				Dim rowField = New RowField(entity.[GetType]().Name, DirectCast(entity, IHasUpdateInfo).UpdateInfo.RowNumber)

				Dim message = New ApplicationMessage(DB_ERR, rowField, sb.ToString())
				Throw New BusinessException(message, e)
			End Try

			Return ret
		End Function
		#End Region
	End Class
End Namespace

