
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Common
Imports System.Data.Entity
Imports System.Linq
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading.Tasks

Imports log4net

Namespace Common.DataAccess
	''' <summary>
	''' 基底データアクセス層
	''' </summary>
	Public Class BaseDA
		#Region "ロガーフィールド"
		Private m_logger As ILog
		#End Region

		#Region "プロパティ"
		''' <summary>ロガー</summary>
		Protected ReadOnly Property Log() As ILog
			Get
				Return m_logger
			End Get
		End Property

		''' <summary>DBプロバイダファクトリ</summary>
		Protected Property ProviderFactory() As DbProviderFactory
			Get
				Return m_ProviderFactory
			End Get
			Set
				m_ProviderFactory = Value
			End Set
		End Property
		Private m_ProviderFactory As DbProviderFactory

		''' <summary>データアダプタ</summary>
		Protected Property DataAdapter() As IDbDataAdapter
			Get
				Return m_DataAdapter
			End Get
			Set
				m_DataAdapter = Value
			End Set
		End Property
		Private m_DataAdapter As IDbDataAdapter
		#End Region

		#Region "コンストラクタ"
		''' <summary>
		''' コンストラクタ
		''' </summary>
		Public Sub New()
			' ロガーを取得
			m_logger = LogManager.GetLogger(Me.[GetType]())

			' DBプロバイダファクトリ作成
			ProviderFactory = DbProviderFactories.GetFactory(Properties.Settings.[Default].DbProviderFactory)
			' データアダプタはfactoryから作成する
			DataAdapter = ProviderFactory.CreateDataAdapter()
		End Sub
		#End Region

		#Region "protectedメソッド"
		''' <summary>
		''' DBプロバイダファクトリに関連付けられたCommandを作成する。
		''' </summary>
		''' <param name="argCommandText">Commandに設定するSQL文</param>
		''' <param name="argDbContext">DbContext</param>
		''' <returns>DBプロバイダファクトリに関連付けられたCommand</returns>
		Protected Function CreateCommand(argCommandText As String, argDbContext As DbContext) As IDbCommand
			Dim cmd As IDbCommand = ProviderFactory.CreateCommand()
			cmd.CommandText = argCommandText
			cmd.Connection = argDbContext.Database.Connection

			Return cmd
		End Function

		''' <summary>
		''' DBプロバイダファクトリに関連付けられたCommandパラメータを作成する。
		''' </summary>
		''' <param name="argParameterName">パラメータ名</param>
		''' <param name="argValue">値</param>
		''' <returns>DBプロバイダファクトリに関連付けられたCommandパラメータ</returns>
		Protected Function CreateCmdParam(argParameterName As String, ParameterName As Object) As IDbDataParameter
			Dim param As IDbDataParameter = ProviderFactory.CreateParameter()
			param.ParameterName = argParameterName
			param.Value = ParameterName
			Return param
		End Function

		''' <summary>
		''' StringBuilderに検索条件を追加する。
		''' </summary>
		''' <param name="argWhereSb">検索条件を追加するStringBuilder</param>
		''' <param name="argParam">検索条件</param>
		''' <remarks>argWhereSbの長さが0の場合は項目名から文字列を追加する。
		''' 0でない場合はANDから文字列を追加する。</remarks>
		Protected Sub AddWhere(argWhereSb As StringBuilder, argParam As IEnumerable(Of SelectParam))
			' 追加の条件
			For Each param As var In argParam
				If String.IsNullOrEmpty(param.Condtion) Then
					Continue For
				End If

				If argWhereSb.Length > 0 Then
					argWhereSb.AppendLine().Append("AND ")
				End If
				If Not String.IsNullOrEmpty(param.Name) Then
					' テーブルの指定がない場合は、Aをつける
					If Not param.Name.Contains("."C) Then
						argWhereSb.Append("A.")
					End If
					argWhereSb.AppendFormat("{0} ", param.Name)
				End If
				argWhereSb.Append(param.Condtion)
			Next
		End Sub

		''' <summary>
		''' Commandに検索パラメータを設定する。
		''' </summary>
		''' <param name="argCmd">IDbCommand</param>
		''' <param name="argParam">検索条件</param>
		Protected Sub SetParameter(argCmd As IDbCommand, argParam As IEnumerable(Of SelectParam))
			Dim regex As New Regex("@\w+")

			For Each param As var In argParam
				' プレースフォルダ名を取得
				Dim mc As MatchCollection = regex.Matches(param.Condtion)
				If mc.Count = 0 Then
					Continue For
				End If

				If param.FromValue IsNot Nothing AndAlso param.ToValue IsNot Nothing Then
					argCmd.Parameters.Add(CreateCmdParam(mc(0).Value, param.FromValue))
					argCmd.Parameters.Add(CreateCmdParam(mc(1).Value, param.ToValue))
				Else
					If param.FromValue IsNot Nothing Then
						argCmd.Parameters.Add(CreateCmdParam(mc(0).Value, param.FromValue))
					End If
					If param.ToValue IsNot Nothing Then
						argCmd.Parameters.Add(CreateCmdParam(mc(0).Value, param.ToValue))
					End If
				End If
			Next
		End Sub
		#End Region
	End Class
End Namespace

