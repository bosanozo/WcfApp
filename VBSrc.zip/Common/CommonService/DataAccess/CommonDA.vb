
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Entity
Imports System.Linq
Imports System.Reflection
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading.Tasks

Imports Common.Models

Namespace Common.DataAccess
	''' <summary>
	''' 共通処理データアクセス層
	''' </summary>
	Public Class CommonDA
		Inherits BaseDA
		#Region "private変数"
		Private m_dbContext As BaseDbContext
		#End Region

		#Region "SELECT文作成用SQL"
		''' <summary>
		''' 共通項目(作成・更新情報)
		''' </summary>
		Private Const UPDATE_INFO_COLS As String = "A.作成日時," + "A.作成者ID," + "US1.ユーザ名 作成者名," + "A.作成者IP," + "A.作成PG," + vbCr & vbLf + "A.更新日時," + "A.更新者ID," + "US2.ユーザ名 更新者名," + "A.更新者IP," + "A.更新PG," + "A.排他用バージョン"

		''' <summary>
		''' 作成者名、更新者名取得用JOIN
		''' </summary>
		Private Const UPDATE_INFO_JOIN As String = "LEFT JOIN CMSMユーザ US1 ON US1.ユーザID = A.作成者ID" + vbCr & vbLf + "LEFT JOIN CMSMユーザ US2 ON US2.ユーザID = A.更新者ID"

		''' <summary>
		''' 最大検索件数の項目
		''' </summary>
		Private Const ROWNUMBER_COL As String = "ROW_NUMBER() OVER (ORDER BY {0}) - 1 ROWNUMBER"

		''' <summary>
		''' 最大検索件数の条件
		''' </summary>
		Private Const ROWNUMBER_CONDITION As String = "WHERE ROWNUMBER <= @最大検索件数 "

		''' <summary>
		''' SELECT文
		''' </summary>
		Private Const SELECT_SQL As String = "SELECT " + "'0' 削除, A.* " + "FROM ({0}) A " + "{1}" + "ORDER BY ROWNUMBER"

		''' <summary>
		''' 適用期間チェックSELECT文
		''' </summary>
		Private Const SELECT_SPAN_SQL As String = "SELECT NULL FROM {0} WHERE 適用終了日 >= TO_CHAR(@1, 'YYYYMMDD') AND 適用開始日 <= TO_CHAR(@1, 'YYYYMMDD')"
		#End Region

		#Region "コンストラクタ"
		''' <summary>
		''' コンストラクタ
		''' </summary>
		''' <param name="argDbContext">DbContext</param>
		Public Sub New(argDbContext As BaseDbContext)
			m_dbContext = argDbContext
		End Sub
		#End Region

		#Region "publicメソッド"
		''' <summary>
		''' ログイン処理を行う。
		''' </summary>
		''' <param name="argUserName">ユーザID</param>
		''' <param name="argPassword">パスワード</param>
		''' <returns>true:成功, false:失敗</returns>
		Public Function Login(argUserName As String, argPassword As String) As Boolean
			Dim success As Boolean = m_dbContext.CMSMユーザ.Where(Function(r) r.ユーザID = argUserName AndAlso r.パスワード = argPassword).Count() > 0

			If success Then
				InformationManager.UserInfo = GetUserInfo(argUserName)
			End If

			Return success
		End Function

		''' <summary>
		''' ユーザ情報を検索する。
		''' </summary>
		''' <param name="argId">ユーザID</param>
		''' <returns>ユーザ情報</returns>
		Public Function GetUserInfo(argId As String) As UserInformation
			Dim result = m_dbContext.Database.SqlQuery(Of UserInformation)(Properties.Resources.UserInfo, argId).First()

			Dim roles = From r In m_dbContext.CMSMユーザロール Where r.ユーザID = argIdr.ロールID

			result.Roles = roles.ToArray()

			Return result
		End Function

		''' <summary>
		''' 最大検索件数を返す。
		''' </summary>
		''' <param name="argId">画面ID</param>
		''' <returns>最大検索件数</returns>
		Public Function GetMaxRow(Optional argId As String = Nothing) As Integer
			If argId Is Nothing Then
				argId = InformationManager.ClientInfo.FormId
			End If

			Dim result = From r In m_dbContext.CMSM汎用基準値 Where r.分類CD = "V001" AndAlso r.基準値CD = argIdr.基準値1

			If result.Count() > 0 AndAlso result.First().HasValue Then
				Return Convert.ToInt32(result.First().Value)
			Else
				Return 1000
			End If
		End Function

		''' <summary>
		''' 指定された検索IDのSQL、パラメータで検索を実行する。
		''' </summary>
		''' <param name="argSelectId">検索ID</param>
		''' <param name="argParams">検索パラメータ</param>
		''' <returns>検索結果</returns>
		Public Function [Select](argSelectId As String, ParamArray argParams As Object()) As DataSet
			' SQL文を取得
			Dim sqltext = Properties.Resources.ResourceManager.GetString(argSelectId)

			' SELECT文の設定
			Dim cmd As IDbCommand = CreateCommand(sqltext, m_dbContext)
			DataAdapter.SelectCommand = cmd

			' パラメータの設定
			For i As Integer = 0 To argParams.Length - 1
				cmd.Parameters.Add(CreateCmdParam((i + 1).ToString(), argParams(i)))
			Next

			' データセットの作成
			Dim result As New DataSet()
			' データの取得
			DataAdapter.Fill(result)
			' テーブル名を設定
			result.Tables("Table").TableName = argSelectId

			' 検索結果の返却
			Return result
		End Function

		''' <summary>
		''' 指定された検索IDのSQLファイルからSELECT文を作成し、検索を実行する。
		''' </summary>
		''' <param name="argSelectIdList">検索IDリスト</param>
		''' <param name="argParamList">検索条件リスト</param>
		''' <param name="argSelectType">検索種別</param>
		''' <param name="argMaxRow">最大検索件数</param>
		''' <param name="argIsOver">最大検索件数オーバーフラグ</param>
		''' <returns>検索結果</returns>
		Public Function SelectList(argSelectIdList As List(Of SelectId), argParamList As List(Of SelectParam), argSelectType As SelectType, argMaxRow As Integer, ByRef argIsOver As Boolean) As DataSet
			' データセットの作成
			Dim result As New DataSet()

			Dim regex = New Regex("-- (\w+) [[]検索条件[]]")

			For Each selectId As var In argSelectIdList
				' ２テーブル目以降は最大検索件数の条件をつけない
				Dim selectType__1 = If(argSelectIdList.IndexOf(selectId) > 0 AndAlso argSelectType = SelectType.Limited, SelectType.All, argSelectType)

				' SQL文を取得
				Dim sqltext = Properties.Resources.ResourceManager.GetString(selectId.Id)

				' 検索条件があるかチェック
				Dim match = regex.Match(sqltext)

				' SQL文を取得
				Dim sql = New StringBuilder(sqltext)

				' 共通項目、ROWNUMBERの項目を設定
				sql.Replace("-- [共通項目]", (Convert.ToString(",") & UPDATE_INFO_COLS) + "," + Environment.NewLine + String.Format(ROWNUMBER_COL, selectId.Order))

				' ROWNUMBERの項目を設定
				sql.Replace("-- [ROWNUMBER]", "," + String.Format(ROWNUMBER_COL, selectId.Order))

				' 共通項目のJOINを設定
				sql.Replace("-- [共通JOIN]", UPDATE_INFO_JOIN)

				' 検索IDが一致するものと検索IDなしを抽出
				Dim param = From p In argParamList Where p.SelectId = selectId.Id OrElse String.IsNullOrEmpty(p.SelectId)p

				' WHERE句作成
				If match.Success Then
					Dim where As New StringBuilder()
					AddWhere(where, param)
					If where.Length > 0 Then
						sql.Replace("-- " + match.Groups(1).Value + " [検索条件]", match.Groups(1).Value + " " + where)
					End If
				End If

				' SELECT文の設定
				Dim cmd As IDbCommand = CreateCommand(String.Format(SELECT_SQL, sql, If(selectType__1 = SelectType.Limited, ROWNUMBER_CONDITION, "")), m_dbContext)
				DataAdapter.SelectCommand = cmd

				' パラメータの設定
				SetParameter(cmd, param)
				' 最大検索件数のパラメータ
				If selectType__1 = SelectType.Limited Then
					cmd.Parameters.Add(CreateCmdParam("最大検索件数", argMaxRow))
				End If

				' データの取得
				DataAdapter.Fill(result)
				' テーブル名を設定
				result.Tables("Table").TableName = selectId.Id
			Next

			' 最初のデータテーブルで検索件数オーバーを判定
			Dim cnt As Integer = result.Tables(0).Rows.Count

			' 最大検索件数オーバーの場合、最終行を削除
			If argSelectType = SelectType.Limited AndAlso cnt >= argMaxRow Then
				argIsOver = True
				result.Tables(0).Rows.RemoveAt(cnt - 1)
			Else
				argIsOver = False
			End If

			' 検索結果の返却
			Return result
		End Function

		''' <summary>
		''' データセットのデータを登録する。
		''' </summary>
		''' <param name="argDataSet">登録データ</param>
		''' <returns>処理件数</returns>
		Public Function Update(argDataSet As DataSet) As Integer
			Dim cnt As Integer = 0

			For Each table As DataTable In argDataSet.Tables
				' 動的に処理対象のエンティティに応じた型を取得
				Dim entityType = Type.[GetType]("Common.Models." + table.TableName)
				Dim listType = GetType(List(Of )).MakeGenericType(entityType)
				Dim method = listType.GetMethod("get_Item", New Type() {GetType(Integer)})

				' Listに変換
				Dim entityList = AutoMapper.Mapper.DynamicMap(table.CreateDataReader(), GetType(IDataReader), listType)

				' 各レコード毎の処理
				For i As Integer = 0 To table.Rows.Count - 1
					Dim entity = method.Invoke(entityList, New Object() {i})
					Dim row As DataRow = table.Rows(i)

					' レコードの状態に応じてDbContextに登録
					If row.RowState = DataRowState.Added Then
						m_dbContext.Entry(entity).State = EntityState.Added
					Else
						' 更新情報を設定
						Dim huEntity = TryCast(entity, IHasUpdateInfo)
						If huEntity IsNot Nothing Then
							Dim updateInfo = huEntity.UpdateInfo
							updateInfo.CreateDate = DirectCast(row("作成日時"), DateTime)
							updateInfo.CreateId = row("作成者ID").ToString()
							updateInfo.CreateHost = row("作成者IP").ToString()
							updateInfo.CreatePg = row("作成PG").ToString()
							updateInfo.Version = DirectCast(row("排他用バージョン"), Byte())
							updateInfo.RowNumber = CommonUtil.GetRowNumber(row)
						End If

						If row("削除").ToString() = "1" Then
							m_dbContext.Entry(entity).State = EntityState.Deleted
						Else
							m_dbContext.Entry(entity).State = EntityState.Modified
						End If
					End If
				Next
			Next

			m_dbContext.SaveChanges()

			Return cnt
		End Function
		#End Region
	End Class
End Namespace

