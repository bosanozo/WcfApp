
Imports System.IO
Imports System.Windows.Forms
Imports System.ServiceModel

Imports Microsoft.Practices.Unity.InterceptionExtension

Imports log4net

Imports Common
Imports Common.Forms
Imports Common.Service

Namespace Common.Unity
	''' <summary>
	''' 処理中ダイアログを表示する。
	''' </summary>
	Public Class ShowWaitingHandler
		Implements ICallHandler
		#Region "ロガーフィールド"
		Private m_logger As ILog
		#End Region

		''' <summary>
		''' Order
		''' </summary>
		Public Property Order() As Integer
			Get
				Return m_Order
			End Get
			Set
				m_Order = Value
			End Set
		End Property
		Private m_Order As Integer

		#Region "コンストラクタ"
		''' <summary>
		''' コンストラクタ
		''' </summary>
		Public Sub New()
			' ロガーを取得
			m_logger = LogManager.GetLogger(Me.[GetType]())
		End Sub
		#End Region

		''' <summary>
		''' メソッドの実行中カーソルを処理中に変更する。
		''' </summary>
		''' <param name="input">IMethodInvocation</param>
		''' <param name="getNext">GetNextHandlerDelegate</param>
		''' <returns>IMethodReturn</returns>
		Public Function Invoke(input As IMethodInvocation, getNext As GetNextHandlerDelegate) As IMethodReturn
			Dim returnMessage As IMethodReturn = Nothing

			' フォームを取得
			Dim form = DirectCast(input.Target, Form)

			' 画面IDを設定
			InformationManager.ClientInfo.FormId = form.[GetType]().BaseType.Name

			' フォーム操作不可
			form.Enabled = False

			' カーソルを処理中に変更
			Dim orgCursor = form.Cursor
			form.Cursor = Cursors.WaitCursor

			' メソッド実行
			returnMessage = getNext()(input, getNext)

			' フォームをアクティブにする
			form.Activate()

			' 処理中に溜まったイベントを処理
			Application.DoEvents()

			' カーソルを戻す
			form.Cursor = orgCursor

			' フォーム操作可
			form.Enabled = True

			' 例外処理
			If returnMessage.Exception IsNot Nothing Then
				Dim message As ApplicationMessage

				If TypeOf returnMessage.Exception Is FaultException(Of ApplicationMessage) Then
					Dim faultEx = TryCast(returnMessage.Exception, FaultException(Of ApplicationMessage))
					message = faultEx.Detail
					m_logger.[Error](message, faultEx)
				ElseIf TypeOf returnMessage.Exception Is FaultException(Of ExceptionDetail) Then
					Dim faultEx = TryCast(returnMessage.Exception, FaultException(Of ExceptionDetail))
					message = New ApplicationMessage("EV001", GetDialogMessage(faultEx.Detail))
					m_logger.[Error](message, faultEx)
				Else
					' 業務エラーの場合
					If TypeOf returnMessage.Exception Is BusinessException Then
						message = DirectCast(returnMessage.Exception, BusinessException).ApplicationMessage
					Else
						' その他の場合
						Dim msgCd As String = "EV001"

						If TypeOf returnMessage.Exception Is FileNotFoundException Then
							msgCd = "W"
						ElseIf TypeOf returnMessage.Exception Is IOException Then
							msgCd = "EV003"
						End If

						message = New ApplicationMessage(msgCd, CommonUtil.GetExceptionMessage(returnMessage.Exception))
					End If
					m_logger.[Error](message, returnMessage.Exception)
				End If

				CustomMessageBox.Show(message)

				returnMessage.Exception = Nothing
			End If

			Return returnMessage
		End Function

		''' <summary>
		''' ダイアログに表示するメッセージを返す。
		''' </summary>
		''' <param name="argExDetail">ExceptionDetail</param>
		''' <returns>ダイアログに表示するメッセージ</returns>
		Private Function GetDialogMessage(argExDetail As ExceptionDetail) As String
			Return argExDetail.Message + (If(argExDetail.InnerException IsNot Nothing, System.Environment.NewLine + GetDialogMessage(argExDetail.InnerException), Nothing))
		End Function
	End Class
End Namespace

