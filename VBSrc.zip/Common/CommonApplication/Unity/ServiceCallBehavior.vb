
Imports System.Collections.Generic
Imports System.Linq
Imports System.Threading
Imports System.Threading.Tasks
Imports System.Windows.Forms
Imports System.ServiceModel.Security

Imports Microsoft.Practices.Unity
Imports Microsoft.Practices.Unity.InterceptionExtension

Imports Common.Forms

Namespace Common.Unity
	''' <summary>
	''' サービス呼び出しをハンドリングする。
	''' </summary>
	Public Class ServiceCallBehavior
		Implements IInterceptionBehavior
		''' <summary>
		''' サービス呼び出しをハンドリングする。
		''' </summary>
		''' <param name="input">IMethodInvocation</param>
		''' <param name="getNext">GetNextInterceptionBehaviorDelegate</param>
		''' <returns>IMethodReturn</returns>
		Public Function Invoke(input As IMethodInvocation, getNext As GetNextInterceptionBehaviorDelegate) As IMethodReturn
			' ハンドリングしたメソッド実行
			Dim returnMessage As IMethodReturn = InvokeMethod(input, getNext)

			' 例外処理
			If returnMessage.Exception IsNot Nothing Then
				Dim securityEx = TryCast(returnMessage.Exception, MessageSecurityException)
				If securityEx IsNot Nothing Then
					Using loginDialog = UnityContainerManager.Container.Resolve(Of LoginDialog)()
						If loginDialog.ShowDialog() = DialogResult.OK Then
							' ログイン画面消去
							Application.DoEvents()
							' メソッド再実行
							returnMessage = InvokeMethod(input, getNext)
						End If
						'MessageBox.Show(faultEx.Detail.Type + "\n" + faultEx.Detail.Message);                    
					End Using
				End If
			End If
			Return returnMessage
		End Function

		''' <summary>
		''' ハンドリングしたメソッド実行し、実行時間が長い場合、処理中ダイアログを表示する。
		''' 認証エラーが発生した場合、ログインダイアログを表示する。
		''' </summary>
		''' <param name="input">IMethodInvocation</param>
		''' <param name="getNext">GetNextHandlerDelegate</param>
		''' <returns>IMethodReturn</returns>
		Private Function InvokeMethod(input As IMethodInvocation, getNext As GetNextInterceptionBehaviorDelegate) As IMethodReturn
			Dim returnMessage As IMethodReturn = Nothing

			' フォームを取得
			Dim form__1 = Form.ActiveForm

			If form__1 IsNot Nothing Then
				' ダイアログを作成
				Using dlg = New WaitingDialog()
					' ハンドリングしたメソッドを非同期実行
					Dim ar As IAsyncResult = getNext().BeginInvoke(input, getNext, Function(asyncResult) 
					' 結果を取得
					returnMessage = getNext().EndInvoke(asyncResult)

					' UIスレッドで処理を実行
					form__1.Invoke(DirectCast(dlg.Close, MethodInvoker))

End Function, Nothing)

					' ダイアログ表示待ち
					If Not ar.AsyncWaitHandle.WaitOne(TimeSpan.FromSeconds(Properties.Settings.[Default].DialogWaitTime)) Then
						dlg.ShowDialog()
					End If

					' 結果がまだ無い場合の対処
					While returnMessage Is Nothing
						Thread.Sleep(10)
					End While
				End Using
			Else
				returnMessage = getNext()(input, getNext)
			End If

			Return returnMessage
		End Function

		Public Function GetRequiredInterfaces() As IEnumerable(Of Type)
			Return Enumerable.Empty(Of Type)()
		End Function

		Public ReadOnly Property WillExecute() As Boolean
			Get
				Return True
			End Get
		End Property
	End Class

End Namespace

