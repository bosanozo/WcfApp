
Imports Microsoft.Practices.Unity

Namespace Common.Unity
	''' <summary>
	''' UnityContainerの単一のインスタンスを管理する。
	''' </summary>
	Public Class UnityContainerManager
		Private Shared s_container As IUnityContainer = New UnityContainer()

		''' <summary>
		''' UnityContainerの単一のインスタンスを返す
		''' </summary>
		Public Shared ReadOnly Property Container() As IUnityContainer
			Get
				Return s_container
			End Get
		End Property
	End Class
End Namespace

