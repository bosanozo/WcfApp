

Imports Microsoft.Practices.Unity
Imports Microsoft.Practices.Unity.InterceptionExtension

Namespace Common.Unity
	''' <summary>
	''' 処理中を表示するメソッドにつけるAttribute
	''' </summary>
	<AttributeUsage(AttributeTargets.Method)> _
	Public Class ShowWaitingAttribute
		Inherits HandlerAttribute
		''' <summary>
		''' ShowWaitingHandlerを作成する。
		''' </summary>
		''' <param name="container">IUnityContainer</param>
		''' <returns>ShowWaitingHandler</returns>
		Public Overrides Function CreateHandler(container As IUnityContainer) As ICallHandler
			Return New ShowWaitingHandler()
		End Function
	End Class
End Namespace

