
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms

Imports Microsoft.Practices.Unity

Imports Common
Imports Common.Unity

Namespace Common.Forms
	''' <summary>
	''' メイン画面の基底クラス
	''' </summary>
	Public Partial Class MainForm
		Inherits BaseForm
		#Region "コンストラクタ"
		''' <summary>
		''' コンストラクタ
		''' </summary>
		Public Sub New()
			InitializeComponent()
		End Sub
		#End Region

		#Region "イベントハンドラ"
		''' <summary>
		''' 検索ボタン押下
		''' </summary>
		<ShowWaiting> _
		Protected Overridable Sub button1_Click(sender As Object, e As EventArgs)
			Dim idList = New List(Of SelectId)() From { _
				New SelectId("CMSM組織", "A.組織CD") _
			}

			' 検索パラメータ作成
			Dim paramList = New List(Of SelectParam)()
			If textBox1.Text.Length > 0 Then
				paramList.Add(New SelectParam("組織CD", "= @組織CD", textBox1.Text))
			End If
			If textBox2.Text.Length > 0 Then
				paramList.Add(New SelectParam("組織名", "Like @組織名", "%" + textBox2.Text + "%"))
			End If

			' 検索実行
			Dim message As ApplicationMessage
			Dim result = CommonService.SelectList(idList, paramList, SelectType.Limited, message)

			' 返却メッセージの表示
			If message IsNot Nothing Then
				CustomMessageBox.Show(message)
			End If

			' 検索結果を設定
			dataGridView1.DataSource = result.Tables(0)

			dataGridView1.Columns.Remove("排他用バージョン")
		End Sub

		''' <summary>
		''' 条件クリアボタン押下
		''' </summary>
		Private Sub button2_Click(sender As Object, e As EventArgs)
			For Each c As Control In tableLayoutPanel1.Controls
				If TypeOf c Is TextBox Then
					DirectCast(c, TextBox).Clear()
				End If
			Next
		End Sub

		''' <summary>
		''' 編集ボタン押下
		''' </summary>
		<ShowWaiting> _
		Protected Overridable Sub button3_Click(sender As Object, e As EventArgs)
			' 画面表示時に引数として渡す操作モードの設定
			Dim opeMode As OperationMode
			If sender = button3 Then
				opeMode = OperationMode.[New]
			ElseIf sender = button4 Then
				opeMode = OperationMode.Update
			ElseIf sender = button5 Then
				opeMode = OperationMode.Delete
			Else
				opeMode = OperationMode.View
			End If

			' 選択行を取得
			Dim selectIdx As Integer = -1

			For i As Integer = 0 To dataGridView1.Rows.Count - 1
				Dim val As Object = dataGridView1("選択", i).Value
				If val IsNot Nothing AndAlso CBool(val) Then
					selectIdx = i
					Exit For
				End If
			Next

			' 選択行が無い場合
			If selectIdx < 0 Then
				' 修正、削除、参照の場合
				If opeMode <> OperationMode.[New] Then
					CustomMessageBox.Show("WV104")
					Return
				End If
			End If

			Dim paramRow As DataRow = Nothing
			' 選択行が１行の場合
			If selectIdx >= 0 Then
				paramRow = DirectCast(dataGridView1.DataSource, DataTable).Rows(selectIdx)
			End If

			' 詳細画面の表示 
			Using detailform = UnityContainerManager.Container.Resolve(Of DetailForm)()
				detailform.SetParam(paramRow, opeMode)
				detailform.ShowDialog()
			End Using
		End Sub

		''' <summary>
		''' 登録ボタン押下
		''' </summary>
		<ShowWaiting> _
		Protected Overridable Sub button7_Click(sender As Object, e As EventArgs)
			' 登録確認OKの場合
			If CustomMessageBox.Show("QV001") = DialogResult.Yes Then
				' 変更データ取得
				Dim changeData = DirectCast(dataGridView1.DataSource, DataTable).DataSet.GetChanges()

				' データの変更が無い場合はメッセージを表示
				If changeData Is Nothing Then
					CustomMessageBox.Show("WV106")
					Return
				End If

				' 登録実行
				Dim message As ApplicationMessage
				Dim result = CommonService.Update(changeData, message)

				' メッセージの表示
				CustomMessageBox.Show("IV003")
			End If
		End Sub
		#End Region
	End Class
End Namespace

