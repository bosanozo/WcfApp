
Namespace Common.Forms
	Partial Class MenuForm
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Dim treeNode1 As New System.Windows.Forms.TreeNode("MainForm")
			Dim treeNode2 As New System.Windows.Forms.TreeNode("テスト", New System.Windows.Forms.TreeNode() {treeNode1})
			Me.treeView1 = New System.Windows.Forms.TreeView()
			Me.SuspendLayout()
			' 
			' treeView1
			' 
			Me.treeView1.Dock = System.Windows.Forms.DockStyle.Fill
			Me.treeView1.Location = New System.Drawing.Point(0, 0)
			Me.treeView1.Name = "treeView1"
			treeNode1.Name = "ノード1"
			treeNode1.Text = "MainForm"
			treeNode2.Name = "ノード0"
			treeNode2.Text = "テスト"
			Me.treeView1.Nodes.AddRange(New System.Windows.Forms.TreeNode() {treeNode2})
			Me.treeView1.Size = New System.Drawing.Size(184, 612)
			Me.treeView1.TabIndex = 0
			Me.treeView1.NodeMouseClick += New System.Windows.Forms.TreeNodeMouseClickEventHandler(Me.treeView1_NodeMouseClick)
			' 
			' MenuForm
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 12F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(184, 612)
			Me.CloseButton = False
			Me.CloseButtonVisible = False
			Me.Controls.Add(Me.treeView1)
			Me.DockAreas = DirectCast(((WeifenLuo.WinFormsUI.Docking.DockAreas.Float Or WeifenLuo.WinFormsUI.Docking.DockAreas.DockLeft) Or WeifenLuo.WinFormsUI.Docking.DockAreas.DockRight), WeifenLuo.WinFormsUI.Docking.DockAreas)
			Me.Font = New System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.Name = "MenuForm"
			Me.Text = "メニュー"
			Me.Load += New System.EventHandler(Me.MenuForm_Load)
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private treeView1 As System.Windows.Forms.TreeView
	End Class
End Namespace

