
Namespace Common.Forms
	Partial Class ContainerForm
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Dim dockPanelSkin1 As New WeifenLuo.WinFormsUI.Docking.DockPanelSkin()
			Dim autoHideStripSkin1 As New WeifenLuo.WinFormsUI.Docking.AutoHideStripSkin()
			Dim dockPanelGradient1 As New WeifenLuo.WinFormsUI.Docking.DockPanelGradient()
			Dim tabGradient1 As New WeifenLuo.WinFormsUI.Docking.TabGradient()
			Dim dockPaneStripSkin1 As New WeifenLuo.WinFormsUI.Docking.DockPaneStripSkin()
			Dim dockPaneStripGradient1 As New WeifenLuo.WinFormsUI.Docking.DockPaneStripGradient()
			Dim tabGradient2 As New WeifenLuo.WinFormsUI.Docking.TabGradient()
			Dim dockPanelGradient2 As New WeifenLuo.WinFormsUI.Docking.DockPanelGradient()
			Dim tabGradient3 As New WeifenLuo.WinFormsUI.Docking.TabGradient()
			Dim dockPaneStripToolWindowGradient1 As New WeifenLuo.WinFormsUI.Docking.DockPaneStripToolWindowGradient()
			Dim tabGradient4 As New WeifenLuo.WinFormsUI.Docking.TabGradient()
			Dim tabGradient5 As New WeifenLuo.WinFormsUI.Docking.TabGradient()
			Dim dockPanelGradient3 As New WeifenLuo.WinFormsUI.Docking.DockPanelGradient()
			Dim tabGradient6 As New WeifenLuo.WinFormsUI.Docking.TabGradient()
			Dim tabGradient7 As New WeifenLuo.WinFormsUI.Docking.TabGradient()
			Me.panelHeadIn = New System.Windows.Forms.Panel()
			Me.panelHeader = New System.Windows.Forms.TableLayoutPanel()
			Me.labelFormId = New System.Windows.Forms.Label()
			Me.labelDateTime = New System.Windows.Forms.Label()
			Me.labelUserName = New System.Windows.Forms.Label()
			Me.labelFormName = New System.Windows.Forms.Label()
			Me.dockPanel1 = New WeifenLuo.WinFormsUI.Docking.DockPanel()
			Me.panelHeadIn.SuspendLayout()
			Me.panelHeader.SuspendLayout()
			Me.SuspendLayout()
			' 
			' panelHeadIn
			' 
			Me.panelHeadIn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
			Me.panelHeadIn.Controls.Add(Me.panelHeader)
			Me.panelHeadIn.Dock = System.Windows.Forms.DockStyle.Top
			Me.panelHeadIn.Location = New System.Drawing.Point(0, 0)
			Me.panelHeadIn.Name = "panelHeadIn"
			Me.panelHeadIn.Size = New System.Drawing.Size(1008, 32)
			Me.panelHeadIn.TabIndex = 1
			' 
			' panelHeader
			' 
			Me.panelHeader.ColumnCount = 5
			Me.panelHeader.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 16F))
			Me.panelHeader.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F))
			Me.panelHeader.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F))
			Me.panelHeader.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F))
			Me.panelHeader.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F))
			Me.panelHeader.Controls.Add(Me.labelFormId, 4, 0)
			Me.panelHeader.Controls.Add(Me.labelDateTime, 3, 0)
			Me.panelHeader.Controls.Add(Me.labelUserName, 2, 0)
			Me.panelHeader.Controls.Add(Me.labelFormName, 1, 0)
			Me.panelHeader.Dock = System.Windows.Forms.DockStyle.Fill
			Me.panelHeader.Location = New System.Drawing.Point(0, 0)
			Me.panelHeader.Name = "panelHeader"
			Me.panelHeader.RowCount = 1
			Me.panelHeader.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F))
			Me.panelHeader.Size = New System.Drawing.Size(1006, 30)
			Me.panelHeader.TabIndex = 0
			' 
			' labelFormId
			' 
			Me.labelFormId.Dock = System.Windows.Forms.DockStyle.Fill
			Me.labelFormId.Font = New System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.labelFormId.Location = New System.Drawing.Point(856, 0)
			Me.labelFormId.Margin = New System.Windows.Forms.Padding(0)
			Me.labelFormId.Name = "labelFormId"
			Me.labelFormId.Size = New System.Drawing.Size(150, 30)
			Me.labelFormId.TabIndex = 0
			Me.labelFormId.Text = "【AAAA000F01】"
			Me.labelFormId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
			' 
			' labelDateTime
			' 
			Me.labelDateTime.Dock = System.Windows.Forms.DockStyle.Fill
			Me.labelDateTime.Font = New System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.labelDateTime.Location = New System.Drawing.Point(726, 0)
			Me.labelDateTime.Margin = New System.Windows.Forms.Padding(0)
			Me.labelDateTime.Name = "labelDateTime"
			Me.labelDateTime.Size = New System.Drawing.Size(130, 30)
			Me.labelDateTime.TabIndex = 0
			Me.labelDateTime.Text = "2015/01/01 12:00"
			Me.labelDateTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
			' 
			' labelUserName
			' 
			Me.labelUserName.Dock = System.Windows.Forms.DockStyle.Fill
			Me.labelUserName.Font = New System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.labelUserName.Location = New System.Drawing.Point(442, 7)
			Me.labelUserName.Margin = New System.Windows.Forms.Padding(0, 7, 0, 7)
			Me.labelUserName.Name = "labelUserName"
			Me.labelUserName.Size = New System.Drawing.Size(284, 16)
			Me.labelUserName.TabIndex = 0
			Me.labelUserName.Text = "ユーザー名"
			Me.labelUserName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
			' 
			' labelFormName
			' 
			Me.labelFormName.Dock = System.Windows.Forms.DockStyle.Fill
			Me.labelFormName.Font = New System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.labelFormName.Location = New System.Drawing.Point(16, 7)
			Me.labelFormName.Margin = New System.Windows.Forms.Padding(0, 7, 0, 7)
			Me.labelFormName.Name = "labelFormName"
			Me.labelFormName.Size = New System.Drawing.Size(426, 16)
			Me.labelFormName.TabIndex = 0
			Me.labelFormName.Text = "画面名"
			Me.labelFormName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
			' 
			' dockPanel1
			' 
			Me.dockPanel1.Dock = System.Windows.Forms.DockStyle.Fill
			Me.dockPanel1.Location = New System.Drawing.Point(0, 32)
			Me.dockPanel1.Name = "dockPanel1"
			Me.dockPanel1.Size = New System.Drawing.Size(1008, 650)
			dockPanelGradient1.EndColor = System.Drawing.SystemColors.ControlLight
			dockPanelGradient1.StartColor = System.Drawing.SystemColors.ControlLight
			autoHideStripSkin1.DockStripGradient = dockPanelGradient1
			tabGradient1.EndColor = System.Drawing.SystemColors.Control
			tabGradient1.StartColor = System.Drawing.SystemColors.Control
			tabGradient1.TextColor = System.Drawing.SystemColors.ControlDarkDark
			autoHideStripSkin1.TabGradient = tabGradient1
			autoHideStripSkin1.TextFont = New System.Drawing.Font("メイリオ", 9F)
			dockPanelSkin1.AutoHideStripSkin = autoHideStripSkin1
			tabGradient2.EndColor = System.Drawing.SystemColors.ControlLightLight
			tabGradient2.StartColor = System.Drawing.SystemColors.ControlLightLight
			tabGradient2.TextColor = System.Drawing.SystemColors.ControlText
			dockPaneStripGradient1.ActiveTabGradient = tabGradient2
			dockPanelGradient2.EndColor = System.Drawing.SystemColors.Control
			dockPanelGradient2.StartColor = System.Drawing.SystemColors.Control
			dockPaneStripGradient1.DockStripGradient = dockPanelGradient2
			tabGradient3.EndColor = System.Drawing.SystemColors.ControlLight
			tabGradient3.StartColor = System.Drawing.SystemColors.ControlLight
			tabGradient3.TextColor = System.Drawing.SystemColors.ControlText
			dockPaneStripGradient1.InactiveTabGradient = tabGradient3
			dockPaneStripSkin1.DocumentGradient = dockPaneStripGradient1
			dockPaneStripSkin1.TextFont = New System.Drawing.Font("メイリオ", 9F)
			tabGradient4.EndColor = System.Drawing.SystemColors.ActiveCaption
			tabGradient4.LinearGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
			tabGradient4.StartColor = System.Drawing.SystemColors.GradientActiveCaption
			tabGradient4.TextColor = System.Drawing.SystemColors.ActiveCaptionText
			dockPaneStripToolWindowGradient1.ActiveCaptionGradient = tabGradient4
			tabGradient5.EndColor = System.Drawing.SystemColors.Control
			tabGradient5.StartColor = System.Drawing.SystemColors.Control
			tabGradient5.TextColor = System.Drawing.SystemColors.ControlText
			dockPaneStripToolWindowGradient1.ActiveTabGradient = tabGradient5
			dockPanelGradient3.EndColor = System.Drawing.SystemColors.ControlLight
			dockPanelGradient3.StartColor = System.Drawing.SystemColors.ControlLight
			dockPaneStripToolWindowGradient1.DockStripGradient = dockPanelGradient3
			tabGradient6.EndColor = System.Drawing.SystemColors.InactiveCaption
			tabGradient6.LinearGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
			tabGradient6.StartColor = System.Drawing.SystemColors.GradientInactiveCaption
			tabGradient6.TextColor = System.Drawing.SystemColors.InactiveCaptionText
			dockPaneStripToolWindowGradient1.InactiveCaptionGradient = tabGradient6
			tabGradient7.EndColor = System.Drawing.Color.Transparent
			tabGradient7.StartColor = System.Drawing.Color.Transparent
			tabGradient7.TextColor = System.Drawing.SystemColors.ControlDarkDark
			dockPaneStripToolWindowGradient1.InactiveTabGradient = tabGradient7
			dockPaneStripSkin1.ToolWindowGradient = dockPaneStripToolWindowGradient1
			dockPanelSkin1.DockPaneStripSkin = dockPaneStripSkin1
			Me.dockPanel1.Skin = dockPanelSkin1
			Me.dockPanel1.TabIndex = 2
			' 
			' ContainerForm
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 12F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(1008, 682)
			Me.Controls.Add(Me.dockPanel1)
			Me.Controls.Add(Me.panelHeadIn)
			Me.IsMdiContainer = True
			Me.Name = "ContainerForm"
			Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "ContainerForm"
			Me.Load += New System.EventHandler(Me.ContainerForm_Load)
			Me.panelHeadIn.ResumeLayout(False)
			Me.panelHeader.ResumeLayout(False)
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private panelHeadIn As System.Windows.Forms.Panel
		Private panelHeader As System.Windows.Forms.TableLayoutPanel
		Private labelFormId As System.Windows.Forms.Label
		Private labelDateTime As System.Windows.Forms.Label
		Private labelUserName As System.Windows.Forms.Label
		Private labelFormName As System.Windows.Forms.Label
		Private dockPanel1 As WeifenLuo.WinFormsUI.Docking.DockPanel
	End Class
End Namespace

