
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms

Namespace Common.Forms
	''' <summary>
	''' 処理中ダイアログ
	''' </summary>
	Public Partial Class WaitingDialog
		Inherits Form
		Private m_startTime As DateTime

		#Region "コンストラクタ"
		''' <summary>
		''' コンストラクタ
		''' </summary>
		Public Sub New()
			InitializeComponent()
		End Sub

		Public Sub New(argServiceName As String)
			Me.New()
			label2.Text = argServiceName
		End Sub
		#End Region

		''' <summary>
		''' 画面表示
		''' </summary>
		Private Sub ServiceCallingDialog_Shown(sender As Object, e As EventArgs)
			' タイマー起動
			Dim timer1 = New Timer()
			timer1.Interval = 500
			AddHandler timer1.Tick, AddressOf timer1_Tick
			timer1.Start()

			' 経過時間初期設定
			m_startTime = DateTime.Now.AddSeconds(Properties.Settings.[Default].DialogWaitTime * -1)
			button1.Enabled = False
		End Sub

		''' <summary>
		''' タイマー動作
		''' </summary>
		Private Sub timer1_Tick(sender As Object, e As EventArgs)
			Dim timer1 = New Timer()
			Dim span = DateTime.Now - m_startTime
			label1.Text = String.Format("{0:mm\:ss}", span)
			If span.TotalSeconds > 10 Then
				button1.Enabled = True
			End If
		End Sub
	End Class
End Namespace

