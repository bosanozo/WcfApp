
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms

Imports Microsoft.Practices.Unity
Imports WeifenLuo.WinFormsUI.Docking

Imports Common.Unity

Namespace Common.Forms
	''' <summary>
	''' メイン画面のコンテナ画面
	''' </summary>
	Public Partial Class ContainerForm
		Inherits Form
		#Region "コンストラクタ"
		''' <summary>
		''' コンストラクタ
		''' </summary>
		Public Sub New()
			InitializeComponent()
		End Sub
		#End Region

		#Region "イベントハンドラ"
		''' <summary>
		''' フォームロード
		''' </summary>
		Private Sub ContainerForm_Load(sender As Object, e As EventArgs)
			Dim menu As DockContent = UnityContainerManager.Container.Resolve(Of MenuForm)()
			menu.Show(dockPanel1, DockState.DockLeftAutoHide)

			Dim form As BaseForm = UnityContainerManager.Container.Resolve(Of MainForm)()
			form.Show(dockPanel1, DockState.Document)

			' ヘッダの設定
			labelUserName.Text = InformationManager.UserInfo.Name
			labelFormId.Text = "【" + form.[GetType]().BaseType.Name + "】"
			labelFormName.Text = form.FormName
		End Sub
		#End Region
	End Class
End Namespace

