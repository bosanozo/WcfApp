
Namespace Common.Forms
	Partial Class WaitingDialog
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.button1 = New System.Windows.Forms.Button()
			Me.label1 = New System.Windows.Forms.Label()
			Me.label2 = New System.Windows.Forms.Label()
			Me.label3 = New System.Windows.Forms.Label()
			Me.label4 = New System.Windows.Forms.Label()
			Me.SuspendLayout()
			' 
			' button1
			' 
			Me.button1.DialogResult = System.Windows.Forms.DialogResult.Abort
			Me.button1.Location = New System.Drawing.Point(103, 123)
			Me.button1.Name = "button1"
			Me.button1.Size = New System.Drawing.Size(75, 23)
			Me.button1.TabIndex = 3
			Me.button1.Text = "中断"
			Me.button1.UseVisualStyleBackColor = True
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Font = New System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.label1.Location = New System.Drawing.Point(160, 54)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(43, 16)
			Me.label1.TabIndex = 2
			Me.label1.Text = "00:01"
			Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
			' 
			' label2
			' 
			Me.label2.BackColor = System.Drawing.Color.White
			Me.label2.Dock = System.Windows.Forms.DockStyle.Top
			Me.label2.Font = New System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.label2.Location = New System.Drawing.Point(0, 0)
			Me.label2.Name = "label2"
			Me.label2.Size = New System.Drawing.Size(284, 40)
			Me.label2.TabIndex = 0
			Me.label2.Text = "ServiceName"
			Me.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
			' 
			' label3
			' 
			Me.label3.AutoSize = True
			Me.label3.Font = New System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.label3.Location = New System.Drawing.Point(82, 54)
			Me.label3.Name = "label3"
			Me.label3.Size = New System.Drawing.Size(80, 16)
			Me.label3.TabIndex = 4
			Me.label3.Text = "経過時間："
			Me.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
			' 
			' label4
			' 
			Me.label4.Font = New System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.label4.ForeColor = System.Drawing.Color.Red
			Me.label4.Location = New System.Drawing.Point(18, 81)
			Me.label4.Name = "label4"
			Me.label4.Size = New System.Drawing.Size(249, 34)
			Me.label4.TabIndex = 5
			Me.label4.Text = "注：中断ボタンを押下してもサーバ側の処理は継続されます。"
			Me.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
			' 
			' WaitingDialog
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 12F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.CancelButton = Me.button1
			Me.ClientSize = New System.Drawing.Size(284, 162)
			Me.ControlBox = False
			Me.Controls.Add(Me.label4)
			Me.Controls.Add(Me.label3)
			Me.Controls.Add(Me.label2)
			Me.Controls.Add(Me.label1)
			Me.Controls.Add(Me.button1)
			Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
			Me.Name = "WaitingDialog"
			Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
			Me.Text = "サーバ呼び出し中"
			Me.Shown += New System.EventHandler(Me.ServiceCallingDialog_Shown)
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private button1 As System.Windows.Forms.Button
		Private label1 As System.Windows.Forms.Label
		Private label2 As System.Windows.Forms.Label
		Private label3 As System.Windows.Forms.Label
		Private label4 As System.Windows.Forms.Label
	End Class
End Namespace

