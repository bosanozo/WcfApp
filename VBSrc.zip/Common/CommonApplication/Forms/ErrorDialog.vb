
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms

Namespace Common.Forms
	''' <summary>
	''' 例外情報等を表示するためのダイアログです
	''' </summary>
	Public Partial Class ErrorDialog
		Inherits Form
		Private m_TitleMessage As String
		Private m_HeaderMessage As String
		Private m_MessageSummary As String
		Private m_MessageDetail As String

		''' <summary>
		''' コンストラクタ
		''' </summary>
		Public Sub New()
			InitializeComponent()
		End Sub

		''' <summary>
		''' ダイアログのタイトルバーに表示するメッセージ
		''' </summary>
		Public WriteOnly Property TitleMessage() As String
			Set
				m_TitleMessage = value
				Me.Text = m_TitleMessage
			End Set
		End Property
		''' <summary>
		''' ダイアログのヘッダ部に表示するメッセージ
		''' </summary>
		Public WriteOnly Property HeaderMessage() As String
			Set
				m_HeaderMessage = value
				Me.labelHeader.Text = m_HeaderMessage
			End Set
		End Property
		''' <summary>
		''' ダイアログに表示するメッセージ（概要）
		''' </summary>
		Public WriteOnly Property MessageSummary() As String
			Set
				m_MessageSummary = value
				Me.textBoxMessageSummary.Text = m_MessageSummary
			End Set
		End Property
		''' <summary>
		''' ダイアログに表示するメッセージ（詳細）
		''' </summary>
		Public WriteOnly Property MessageDetail() As String
			Set
				m_MessageDetail = value
				Me.textBoxMessageDetail.Text = m_MessageDetail
			End Set
		End Property
		''' <summary>
		''' Form OnLoad
		''' </summary>
		''' <param name="e"></param>
		Protected Overrides Sub OnLoad(e As System.EventArgs)
			MyBase.OnLoad(e)
			' ステータスバーに現在の日付時刻を表示
			Me.toolStripStatusLabelDateTime.Text = System.DateTime.Now.ToShortDateString() + " " + System.DateTime.Now.ToLongTimeString()
		End Sub
		''' <summary>
		''' 「ＯＫ」ボタン　Click
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub buttonOK_Click(sender As Object, e As EventArgs)
			Me.DialogResult = DialogResult.OK
			Me.Close()
		End Sub
		''' <summary>
		''' 「中止」ボタン　Click
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub buttonAbort_Click(sender As Object, e As EventArgs)
			Me.DialogResult = DialogResult.Abort
			Me.Close()
		End Sub
	End Class
End Namespace

