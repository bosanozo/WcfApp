
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms

Imports Microsoft.Practices.Unity
Imports WeifenLuo.WinFormsUI.Docking

Imports Common.Unity

Namespace Common.Forms
	''' <summary>
	''' メニュー画面
	''' </summary>
	Public Partial Class MenuForm
		Inherits BaseForm
		#Region "コンストラクタ"
		''' <summary>
		''' コンストラクタ
		''' </summary>
		Public Sub New()
			InitializeComponent()
		End Sub
		#End Region

		#Region "イベントハンドラ"
		''' <summary>
		''' フォームロード
		''' </summary>
		Private Sub MenuForm_Load(sender As Object, e As EventArgs)
			Dim uinfo As UserInformation = InformationManager.UserInfo

			' メニューレベル１の検索
			Dim table = CommonService.[Select]("CMSMメニューレベル1", uinfo.SoshikiCd, uinfo.Id).Tables(0)

			For Each row As DataRow In table.Rows
				If row("許否フラグ").ToString() = "True" Then
					Dim node = New TreeNode(row("画面名").ToString())
					node.Tag = row("メニューID")
					treeView1.Nodes.Add(node)

					' メニューレベル２の検索
					Dim table2 = CommonService.[Select]("CMSMメニューレベル2", uinfo.SoshikiCd, uinfo.Id, node.Tag).Tables(0)

					For Each row2 As DataRow In table2.Rows
						If row("許否フラグ").ToString() <> "False" Then
							Dim childNode = New TreeNode(row2("画面名").ToString())
							childNode.Tag = row("メニューID")
							node.Nodes.Add(childNode)
						End If
					Next
				End If
			Next
		End Sub

		''' <summary>
		''' メニューツリークリック
		''' </summary>
		Private Sub treeView1_NodeMouseClick(sender As Object, e As TreeNodeMouseClickEventArgs)
			Dim form As BaseForm = UnityContainerManager.Container.Resolve(Of MainForm)()
			form.Show(DockPanel, DockState.Document)
		End Sub
		#End Region
	End Class
End Namespace

