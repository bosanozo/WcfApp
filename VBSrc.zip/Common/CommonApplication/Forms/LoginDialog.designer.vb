
Namespace Common.Forms
	Partial Class LoginDialog
		''' <summary>
		''' 必要なデザイナ変数です。
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' 使用中のリソースをすべてクリーンアップします。
		''' </summary>
		''' <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows フォーム デザイナで生成されたコード"

		''' <summary>
		''' デザイナ サポートに必要なメソッドです。このメソッドの内容を
		''' コード エディタで変更しないでください。
		''' </summary>
		Private Sub InitializeComponent()
			Me.labelMessage = New System.Windows.Forms.Label()
			Me.textBoxUserId = New System.Windows.Forms.TextBox()
			Me.textBoxPassword = New System.Windows.Forms.TextBox()
			Me.buttonLogin = New System.Windows.Forms.Button()
			Me.buttonCancel = New System.Windows.Forms.Button()
			Me.labelSubMessage = New System.Windows.Forms.Label()
			Me.labelUserId = New System.Windows.Forms.Label()
			Me.labelPassword = New System.Windows.Forms.Label()
			Me.label1 = New System.Windows.Forms.Label()
			Me.labelEnvName = New System.Windows.Forms.Label()
			Me.SuspendLayout()
			' 
			' labelMessage
			' 
			Me.labelMessage.Location = New System.Drawing.Point(11, 64)
			Me.labelMessage.Name = "labelMessage"
			Me.labelMessage.Size = New System.Drawing.Size(272, 12)
			Me.labelMessage.TabIndex = 0
			Me.labelMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
			' 
			' textBoxUserId
			' 
			Me.textBoxUserId.ImeMode = System.Windows.Forms.ImeMode.Disable
			Me.textBoxUserId.Location = New System.Drawing.Point(130, 82)
			Me.textBoxUserId.MaxLength = 8
			Me.textBoxUserId.Name = "textBoxUserId"
			Me.textBoxUserId.Size = New System.Drawing.Size(80, 19)
			Me.textBoxUserId.TabIndex = 1
			Me.textBoxUserId.Text = "user01"
			' 
			' textBoxPassword
			' 
			Me.textBoxPassword.ImeMode = System.Windows.Forms.ImeMode.Disable
			Me.textBoxPassword.Location = New System.Drawing.Point(130, 111)
			Me.textBoxPassword.MaxLength = 15
			Me.textBoxPassword.Name = "textBoxPassword"
			Me.textBoxPassword.PasswordChar = "*"C
			Me.textBoxPassword.Size = New System.Drawing.Size(100, 19)
			Me.textBoxPassword.TabIndex = 2
			Me.textBoxPassword.Text = "pass"
			' 
			' buttonLogin
			' 
			Me.buttonLogin.Location = New System.Drawing.Point(126, 163)
			Me.buttonLogin.Name = "buttonLogin"
			Me.buttonLogin.Size = New System.Drawing.Size(75, 23)
			Me.buttonLogin.TabIndex = 3
			Me.buttonLogin.Text = "ログイン"
			Me.buttonLogin.UseVisualStyleBackColor = True
			Me.buttonLogin.Click += New System.EventHandler(Me.buttonLogin_Click)
			' 
			' buttonCancel
			' 
			Me.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
			Me.buttonCancel.Location = New System.Drawing.Point(207, 163)
			Me.buttonCancel.Name = "buttonCancel"
			Me.buttonCancel.Size = New System.Drawing.Size(75, 23)
			Me.buttonCancel.TabIndex = 4
			Me.buttonCancel.Text = "キャンセル"
			Me.buttonCancel.UseVisualStyleBackColor = True
			' 
			' labelSubMessage
			' 
			Me.labelSubMessage.ForeColor = System.Drawing.Color.Red
			Me.labelSubMessage.Location = New System.Drawing.Point(10, 138)
			Me.labelSubMessage.Name = "labelSubMessage"
			Me.labelSubMessage.Size = New System.Drawing.Size(272, 18)
			Me.labelSubMessage.TabIndex = 0
			' 
			' labelUserId
			' 
			Me.labelUserId.AutoSize = True
			Me.labelUserId.Location = New System.Drawing.Point(73, 85)
			Me.labelUserId.Name = "labelUserId"
			Me.labelUserId.Size = New System.Drawing.Size(16, 12)
			Me.labelUserId.TabIndex = 0
			Me.labelUserId.Text = "ID"
			' 
			' labelPassword
			' 
			Me.labelPassword.AutoSize = True
			Me.labelPassword.Location = New System.Drawing.Point(72, 114)
			Me.labelPassword.Name = "labelPassword"
			Me.labelPassword.Size = New System.Drawing.Size(52, 12)
			Me.labelPassword.TabIndex = 0
			Me.labelPassword.Text = "パスワード"
			' 
			' label1
			' 
			Me.label1.BackColor = System.Drawing.Color.White
			Me.label1.Font = New System.Drawing.Font("ＭＳ ゴシック", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.label1.ForeColor = System.Drawing.Color.FromArgb(CInt(CByte(0)), CInt(CByte(53)), CInt(CByte(128)))
			Me.label1.Location = New System.Drawing.Point(4, 4)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(286, 29)
			Me.label1.TabIndex = 0
			Me.label1.Text = "ログイン"
			Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
			' 
			' labelEnvName
			' 
			Me.labelEnvName.Font = New System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.labelEnvName.Location = New System.Drawing.Point(4, 37)
			Me.labelEnvName.Name = "labelEnvName"
			Me.labelEnvName.Size = New System.Drawing.Size(286, 21)
			Me.labelEnvName.TabIndex = 0
			Me.labelEnvName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
			' 
			' LoginDialog
			' 
			Me.AcceptButton = Me.buttonLogin
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 12F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.CancelButton = Me.buttonCancel
			Me.ClientSize = New System.Drawing.Size(294, 198)
			Me.ControlBox = False
			Me.Controls.Add(Me.labelEnvName)
			Me.Controls.Add(Me.label1)
			Me.Controls.Add(Me.labelPassword)
			Me.Controls.Add(Me.labelUserId)
			Me.Controls.Add(Me.labelSubMessage)
			Me.Controls.Add(Me.buttonCancel)
			Me.Controls.Add(Me.buttonLogin)
			Me.Controls.Add(Me.textBoxPassword)
			Me.Controls.Add(Me.textBoxUserId)
			Me.Controls.Add(Me.labelMessage)
			Me.Font = New System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "LoginDialog"
			Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
			Me.Text = "ログイン"
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private labelMessage As System.Windows.Forms.Label
		Private textBoxUserId As System.Windows.Forms.TextBox
		Private textBoxPassword As System.Windows.Forms.TextBox
		Private buttonLogin As System.Windows.Forms.Button
		Private buttonCancel As System.Windows.Forms.Button
		Private labelSubMessage As System.Windows.Forms.Label
		Private labelUserId As System.Windows.Forms.Label
		Private labelPassword As System.Windows.Forms.Label
		Private label1 As System.Windows.Forms.Label
		Private labelEnvName As System.Windows.Forms.Label
	End Class
End Namespace

