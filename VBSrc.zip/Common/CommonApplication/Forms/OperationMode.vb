
' * 【共通部品】
' *
' * 作成者: 豆蔵／田中 望
' * 改版履歴:
' * 2011.11.24, 新規作成


Namespace Common.Forms
	''' <summary>
	''' 操作モード
	''' </summary>
	Public Enum OperationMode
		View
		[New]
		Update
		Delete
	End Enum
End Namespace

