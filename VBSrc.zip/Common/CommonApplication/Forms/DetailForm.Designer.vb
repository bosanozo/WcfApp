
Namespace Common.Forms
	Partial Class DetailForm
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.tableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
			Me.label1 = New System.Windows.Forms.Label()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.label2 = New System.Windows.Forms.Label()
			Me.textBox2 = New System.Windows.Forms.TextBox()
			Me.flowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
			Me.button7 = New System.Windows.Forms.Button()
			Me.tableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
			Me.label3 = New System.Windows.Forms.Label()
			Me.comboBox1 = New System.Windows.Forms.ComboBox()
			Me.tableLayoutPanel1.SuspendLayout()
			Me.flowLayoutPanel2.SuspendLayout()
			Me.tableLayoutPanel2.SuspendLayout()
			Me.SuspendLayout()
			' 
			' tableLayoutPanel1
			' 
			Me.tableLayoutPanel1.ColumnCount = 2
			Me.tableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F))
			Me.tableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
			Me.tableLayoutPanel1.Controls.Add(Me.label1, 0, 0)
			Me.tableLayoutPanel1.Controls.Add(Me.textBox1, 1, 0)
			Me.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top
			Me.tableLayoutPanel1.Location = New System.Drawing.Point(4, 4)
			Me.tableLayoutPanel1.Name = "tableLayoutPanel1"
			Me.tableLayoutPanel1.RowCount = 1
			Me.tableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F))
			Me.tableLayoutPanel1.Size = New System.Drawing.Size(784, 40)
			Me.tableLayoutPanel1.TabIndex = 0
			' 
			' label1
			' 
			Me.label1.Location = New System.Drawing.Point(3, 0)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(114, 24)
			Me.label1.TabIndex = 0
			Me.label1.Text = "組織コード"
			Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
			' 
			' textBox1
			' 
			Me.textBox1.Location = New System.Drawing.Point(123, 3)
			Me.textBox1.Name = "textBox1"
			Me.textBox1.Size = New System.Drawing.Size(100, 19)
			Me.textBox1.TabIndex = 3
			' 
			' label2
			' 
			Me.label2.Location = New System.Drawing.Point(3, 0)
			Me.label2.Name = "label2"
			Me.label2.Size = New System.Drawing.Size(114, 24)
			Me.label2.TabIndex = 2
			Me.label2.Text = "組織名"
			Me.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
			' 
			' textBox2
			' 
			Me.textBox2.Location = New System.Drawing.Point(123, 3)
			Me.textBox2.Name = "textBox2"
			Me.textBox2.Size = New System.Drawing.Size(100, 19)
			Me.textBox2.TabIndex = 4
			' 
			' flowLayoutPanel2
			' 
			Me.flowLayoutPanel2.Controls.Add(Me.button7)
			Me.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.flowLayoutPanel2.Location = New System.Drawing.Point(4, 478)
			Me.flowLayoutPanel2.Name = "flowLayoutPanel2"
			Me.flowLayoutPanel2.Padding = New System.Windows.Forms.Padding(20, 0, 0, 0)
			Me.flowLayoutPanel2.Size = New System.Drawing.Size(784, 30)
			Me.flowLayoutPanel2.TabIndex = 3
			' 
			' button7
			' 
			Me.button7.Location = New System.Drawing.Point(23, 3)
			Me.button7.Name = "button7"
			Me.button7.Size = New System.Drawing.Size(75, 23)
			Me.button7.TabIndex = 5
			Me.button7.Text = "登録"
			Me.button7.UseVisualStyleBackColor = True
			Me.button7.Click += New System.EventHandler(Me.button7_Click)
			' 
			' tableLayoutPanel2
			' 
			Me.tableLayoutPanel2.ColumnCount = 2
			Me.tableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F))
			Me.tableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
			Me.tableLayoutPanel2.Controls.Add(Me.label3, 0, 1)
			Me.tableLayoutPanel2.Controls.Add(Me.label2, 0, 0)
			Me.tableLayoutPanel2.Controls.Add(Me.textBox2, 1, 0)
			Me.tableLayoutPanel2.Controls.Add(Me.comboBox1, 1, 1)
			Me.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top
			Me.tableLayoutPanel2.Location = New System.Drawing.Point(4, 44)
			Me.tableLayoutPanel2.Name = "tableLayoutPanel2"
			Me.tableLayoutPanel2.RowCount = 2
			Me.tableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F))
			Me.tableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F))
			Me.tableLayoutPanel2.Size = New System.Drawing.Size(784, 100)
			Me.tableLayoutPanel2.TabIndex = 4
			' 
			' label3
			' 
			Me.label3.Location = New System.Drawing.Point(3, 50)
			Me.label3.Name = "label3"
			Me.label3.Size = New System.Drawing.Size(114, 24)
			Me.label3.TabIndex = 5
			Me.label3.Text = "組織階層区分"
			Me.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
			' 
			' comboBox1
			' 
			Me.comboBox1.DisplayMember = "基準値名"
			Me.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.comboBox1.FormattingEnabled = True
			Me.comboBox1.Location = New System.Drawing.Point(123, 53)
			Me.comboBox1.Name = "comboBox1"
			Me.comboBox1.Size = New System.Drawing.Size(121, 20)
			Me.comboBox1.TabIndex = 6
			Me.comboBox1.ValueMember = "基準値CD"
			' 
			' DetailForm
			' 
			Me.AcceptButton = Me.button7
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 12F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(792, 512)
			Me.Controls.Add(Me.tableLayoutPanel2)
			Me.Controls.Add(Me.tableLayoutPanel1)
			Me.Controls.Add(Me.flowLayoutPanel2)
			Me.DockAreas = DirectCast((WeifenLuo.WinFormsUI.Docking.DockAreas.Float Or WeifenLuo.WinFormsUI.Docking.DockAreas.Document), WeifenLuo.WinFormsUI.Docking.DockAreas)
			Me.Font = New System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.FormName = "詳細画面"
			Me.Name = "DetailForm"
			Me.Padding = New System.Windows.Forms.Padding(4)
			Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
			Me.Text = "DetailForm"
			Me.Load += New System.EventHandler(Me.DetailForm_Load)
			Me.tableLayoutPanel1.ResumeLayout(False)
			Me.tableLayoutPanel1.PerformLayout()
			Me.flowLayoutPanel2.ResumeLayout(False)
			Me.tableLayoutPanel2.ResumeLayout(False)
			Me.tableLayoutPanel2.PerformLayout()
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private tableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
		Private flowLayoutPanel2 As System.Windows.Forms.FlowLayoutPanel
		Private button7 As System.Windows.Forms.Button
		Private label2 As System.Windows.Forms.Label
		Private label1 As System.Windows.Forms.Label
		Private textBox2 As System.Windows.Forms.TextBox
		Private textBox1 As System.Windows.Forms.TextBox
		Private tableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
		Private label3 As System.Windows.Forms.Label
		Private comboBox1 As System.Windows.Forms.ComboBox
	End Class
End Namespace

