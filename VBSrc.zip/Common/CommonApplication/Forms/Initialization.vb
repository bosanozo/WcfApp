
Imports System.Globalization
Imports System.IO
Imports System.Linq
Imports System.Reflection
Imports System.Windows.Forms
Imports System.ServiceModel
Imports System.Threading

Imports Microsoft.Practices.Unity
Imports Microsoft.Practices.Unity.InterceptionExtension

Imports log4net

Imports Common.Service
Imports Common.Unity
Imports Common.Wcf

Namespace Common.Forms
	''' <summary>
	''' 初期設定関連クラス
	''' </summary>
	Public Class Initialization
		''' <summary>
		''' Windowsアプリケーションの初期設定
		''' </summary>
		Public Shared Function InitialSetting() As Boolean
			' 集約例外ハンドラの設定
			AddHandler Application.ThreadException, AddressOf Application_ThreadException

			' 表示スタイルの設定
			Application.EnableVisualStyles()
			Application.SetCompatibleTextRenderingDefault(False)
			Application.CurrentCulture = New CultureInfo("ja-JP", False)

			'#Region "Unity設定"
			' Unityコンテナ取得
			Dim container = UnityContainerManager.Container

			' Interceptionを拡張
			container.AddNewExtension(Of Interception)()

			' Interceptionの設定
			Dim policyDef As PolicyDefinition = container.Configure(Of Interception)().AddPolicy("Client")
			policyDef.AddMatchingRule(New CustomAttributeMatchingRule(GetType(ShowWaitingAttribute), True))

			' Injection設定
			For Each file As String In Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory, "Common*.dll", SearchOption.AllDirectories)
				Dim asm = Assembly.LoadFile(file)

				' IBaseServiceを継承するInterfaceを登録
				If Properties.Settings.[Default].ServiceCall = "Local" Then
					'getLifetimeManager: t => new PerResolveLifetimeManager(),
					container.RegisterTypes(asm.ExportedTypes.Where(Function(t) t.IsClass = True AndAlso t.GetInterfaces().Contains(GetType(IBaseService))), WithMappings.FromMatchingInterface, getInjectionMembers := Function(t) New InjectionMember() {New Interceptor(Of InterfaceInterceptor)(), New InterceptionBehavior(Of PolicyInjectionBehavior)()})
				Else
					container.RegisterTypes(asm.ExportedTypes.Where(Function(t) t.IsInterface = True AndAlso t.GetInterfaces().Contains(GetType(IBaseService))), getInjectionMembers := Function(t) New InjectionMember() {New InjectionFactory(Function(c) ServiceUtil.GetServiceProxy(t)), New Interceptor(Of InterfaceInterceptor)(), New InterceptionBehavior(Of PolicyInjectionBehavior)(), New InterceptionBehavior(Of ServiceCallBehavior)()})
				End If
			Next

			' BaseFormを継承するクラスを登録
			container.RegisterTypes(AllClasses.FromLoadedAssemblies().Where(Function(c) c.IsSubclassOf(GetType(BaseForm))), getInjectionMembers := Function(t) New InjectionMember() {New Interceptor(Of VirtualMethodInterceptor)(), New InterceptionBehavior(Of PolicyInjectionBehavior)()})

			' Local設定の追加
			If Properties.Settings.[Default].ServiceCall = "Local" Then
				' TransactionAttributeを登録
				Dim t = Type.[GetType]("Common.Unity.UseTransactionAttribute, CommonService")
				policyDef.AddMatchingRule(New CustomAttributeMatchingRule(t, True))

				' DbContextを登録
				Dim t2 = Type.[GetType]("Common.DataAccess.BaseDbContext, CommonService")
				container.RegisterType(t2, New PerResolveLifetimeManager())
			End If
			'#End Region

			' 未認証の場合は、ログイン実行
			If Not Thread.CurrentPrincipal.Identity.IsAuthenticated Then
				InformationManager.ClientInfo = New ClientInformation()

				Using login = container.Resolve(Of LoginDialog)()
					' ログイン画面を表示してログインを実行
					Dim result = login.ShowDialog()

					If result = DialogResult.Abort AndAlso login.Exception IsNot Nothing Then
						' スロー
						Throw login.Exception
					ElseIf result <> DialogResult.OK Then
						Return False
					End If
				End Using
			End If

			Return True
		End Function

		''' <summary>
		''' 集約例外ハンドラ
		''' </summary>
		''' <remarks>
		''' アプリケーション中でキャッチされなかった例外情報を捕捉します。
		''' </remarks>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Shared Sub Application_ThreadException(sender As Object, e As ThreadExceptionEventArgs)
			' 例外情報をログ出力
			Dim logger = LogManager.GetLogger("Common.ThreadException")
			logger.[Error](e.Exception)

			' 例外情報をダイアログ表示
			Dim ret As DialogResult
			Using fm As New ErrorDialog()
				fm.MessageSummary = e.Exception.Message
				fm.MessageDetail = e.Exception.ToString()
				ret = fm.ShowDialog()
			End Using
			' 中止の場合は、アプリケーション終了
			If ret = DialogResult.Abort Then
				Application.ExitThread()
			End If
		End Sub
	End Class
End Namespace

