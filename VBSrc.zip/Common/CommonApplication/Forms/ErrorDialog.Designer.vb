
#Pragma warning disable 1591
Namespace Common.Forms
	Partial Class ErrorDialog
		''' <summary>
		''' 必要なデザイナ変数です。
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' 使用中のリソースをすべてクリーンアップします。
		''' </summary>
		''' <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows フォーム デザイナで生成されたコード"

		''' <summary>
		''' デザイナ サポートに必要なメソッドです。このメソッドの内容を
		''' コード エディタで変更しないでください。
		''' </summary>
		Private Sub InitializeComponent()
			Me.labelHeader = New System.Windows.Forms.Label()
			Me.textBoxMessageSummary = New System.Windows.Forms.TextBox()
			Me.statusStrip1 = New System.Windows.Forms.StatusStrip()
			Me.toolStripStatusLabelDateTime = New System.Windows.Forms.ToolStripStatusLabel()
			Me.splitter1 = New System.Windows.Forms.Splitter()
			Me.panel1 = New System.Windows.Forms.Panel()
			Me.buttonAbort = New System.Windows.Forms.Button()
			Me.textBoxMessageDetail = New System.Windows.Forms.TextBox()
			Me.statusStrip1.SuspendLayout()
			Me.panel1.SuspendLayout()
			Me.SuspendLayout()
			' 
			' labelHeader
			' 
			Me.labelHeader.Dock = System.Windows.Forms.DockStyle.Top
			Me.labelHeader.Location = New System.Drawing.Point(0, 0)
			Me.labelHeader.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.labelHeader.Name = "labelHeader"
			Me.labelHeader.Size = New System.Drawing.Size(458, 43)
			Me.labelHeader.TabIndex = 3
			Me.labelHeader.Text = "アプリケーションで補足されない例外が発生しました。"
			Me.labelHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
			' 
			' textBoxMessageSummary
			' 
			Me.textBoxMessageSummary.Dock = System.Windows.Forms.DockStyle.Top
			Me.textBoxMessageSummary.Font = New System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.textBoxMessageSummary.Location = New System.Drawing.Point(0, 43)
			Me.textBoxMessageSummary.Multiline = True
			Me.textBoxMessageSummary.Name = "textBoxMessageSummary"
			Me.textBoxMessageSummary.[ReadOnly] = True
			Me.textBoxMessageSummary.ScrollBars = System.Windows.Forms.ScrollBars.Both
			Me.textBoxMessageSummary.Size = New System.Drawing.Size(458, 85)
			Me.textBoxMessageSummary.TabIndex = 1
			' 
			' statusStrip1
			' 
			Me.statusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.toolStripStatusLabelDateTime})
			Me.statusStrip1.Location = New System.Drawing.Point(0, 425)
			Me.statusStrip1.Name = "statusStrip1"
			Me.statusStrip1.Size = New System.Drawing.Size(458, 23)
			Me.statusStrip1.TabIndex = 2
			Me.statusStrip1.Text = "statusStrip1"
			' 
			' toolStripStatusLabelDateTime
			' 
			Me.toolStripStatusLabelDateTime.Name = "toolStripStatusLabelDateTime"
			Me.toolStripStatusLabelDateTime.Size = New System.Drawing.Size(135, 18)
			Me.toolStripStatusLabelDateTime.Text = "YYYY/MM/DD HH:MM"
			' 
			' splitter1
			' 
			Me.splitter1.Dock = System.Windows.Forms.DockStyle.Top
			Me.splitter1.Location = New System.Drawing.Point(0, 128)
			Me.splitter1.Name = "splitter1"
			Me.splitter1.Size = New System.Drawing.Size(458, 5)
			Me.splitter1.TabIndex = 5
			Me.splitter1.TabStop = False
			' 
			' panel1
			' 
			Me.panel1.Controls.Add(Me.buttonAbort)
			Me.panel1.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.panel1.Location = New System.Drawing.Point(0, 390)
			Me.panel1.Name = "panel1"
			Me.panel1.Size = New System.Drawing.Size(458, 35)
			Me.panel1.TabIndex = 0
			' 
			' buttonAbort
			' 
			Me.buttonAbort.DialogResult = System.Windows.Forms.DialogResult.Cancel
			Me.buttonAbort.Font = New System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.buttonAbort.Location = New System.Drawing.Point(192, 6)
			Me.buttonAbort.Name = "buttonAbort"
			Me.buttonAbort.Size = New System.Drawing.Size(75, 23)
			Me.buttonAbort.TabIndex = 1
			Me.buttonAbort.Text = "中止"
			Me.buttonAbort.UseVisualStyleBackColor = True
			Me.buttonAbort.Click += New System.EventHandler(Me.buttonAbort_Click)
			' 
			' textBoxMessageDetail
			' 
			Me.textBoxMessageDetail.Dock = System.Windows.Forms.DockStyle.Fill
			Me.textBoxMessageDetail.Font = New System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.textBoxMessageDetail.Location = New System.Drawing.Point(0, 133)
			Me.textBoxMessageDetail.Multiline = True
			Me.textBoxMessageDetail.Name = "textBoxMessageDetail"
			Me.textBoxMessageDetail.[ReadOnly] = True
			Me.textBoxMessageDetail.ScrollBars = System.Windows.Forms.ScrollBars.Both
			Me.textBoxMessageDetail.Size = New System.Drawing.Size(458, 257)
			Me.textBoxMessageDetail.TabIndex = 2
			' 
			' ErrorDialog
			' 
			Me.AcceptButton = Me.buttonAbort
			Me.AutoScaleDimensions = New System.Drawing.SizeF(8F, 16F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.CancelButton = Me.buttonAbort
			Me.ClientSize = New System.Drawing.Size(458, 448)
			Me.Controls.Add(Me.textBoxMessageDetail)
			Me.Controls.Add(Me.panel1)
			Me.Controls.Add(Me.splitter1)
			Me.Controls.Add(Me.statusStrip1)
			Me.Controls.Add(Me.textBoxMessageSummary)
			Me.Controls.Add(Me.labelHeader)
			Me.Font = New System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.Margin = New System.Windows.Forms.Padding(4)
			Me.Name = "ErrorDialog"
			Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "エラー"
			Me.statusStrip1.ResumeLayout(False)
			Me.statusStrip1.PerformLayout()
			Me.panel1.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private labelHeader As System.Windows.Forms.Label
		Private statusStrip1 As System.Windows.Forms.StatusStrip
		Public textBoxMessageSummary As System.Windows.Forms.TextBox
		Private toolStripStatusLabelDateTime As System.Windows.Forms.ToolStripStatusLabel
		Private splitter1 As System.Windows.Forms.Splitter
		Private panel1 As System.Windows.Forms.Panel
		Public textBoxMessageDetail As System.Windows.Forms.TextBox
		Private buttonAbort As System.Windows.Forms.Button
	End Class
End Namespace
#Pragma warning restore 1591

