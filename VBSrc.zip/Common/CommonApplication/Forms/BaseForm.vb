
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.IO
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms

Imports Microsoft.Practices.Unity
Imports WeifenLuo.WinFormsUI.Docking

Imports log4net

Imports Common
Imports Common.Service
Imports Common.Unity

Namespace Common.Forms
	''' <summary>
	''' 画面の基底クラス
	''' </summary>
	Public Partial Class BaseForm
		Inherits DockContent
		#Region "ロガーフィールド"
		Private m_logger As ILog
		#End Region

		#Region "private 変数"
		#End Region

		#Region "プロパティ"
		''' <summary>ロガー</summary>
		Protected ReadOnly Property Log() As ILog
			Get
				Return m_logger
			End Get
		End Property

		''' <summary>共通処理サービス</summary>
		Protected ReadOnly Property CommonService() As ICommonService
			Get
				Return UnityContainerManager.Container.Resolve(Of ICommonService)()
			End Get
		End Property

		''' <summary>確認ダイアログなしクローズフラグ</summary>
		<Category("共通部品")> _
		<Description("確認ダイアログなしクローズフラグ")> _
		Public Property CloseNoConfirm() As Boolean
			Get
				Return m_CloseNoConfirm
			End Get
			Set
				m_CloseNoConfirm = Value
			End Set
		End Property
		Private m_CloseNoConfirm As Boolean

		''' <summary>画面名</summary>
		<Category("共通部品")> _
		<Description("画面名")> _
		<DefaultValue("画面名")> _
		Public Property FormName() As String
			Get
				Return m_FormName
			End Get
			Set
				m_FormName = Value
			End Set
		End Property
		Private m_FormName As String

		''' <summary>操作時刻</summary>
		<Browsable(False)> _
		Public Property OperationTime() As DateTime
			Get
				Return m_OperationTime
			End Get
			Set
				m_OperationTime = Value
			End Set
		End Property
		Private m_OperationTime As DateTime
		#End Region

		#Region "コンストラクタ"
		''' <summary>
		''' コンストラクタ
		''' </summary>
		Public Sub New()
			InitializeComponent()

			' ロガーを取得
			m_logger = LogManager.GetLogger(Me.[GetType]())
		End Sub
		#End Region

		#Region "エラー表示関連メソッド"
		#End Region
	End Class
End Namespace

