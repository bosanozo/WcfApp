
' * 【共通部品】
' *
' * 作成者: 豆蔵／田中 望
' * 改版履歴:
' * 2011.10.20, 新規作成

Imports System.IO
Imports System.Windows.Forms

Imports Common

Namespace Common.Forms
	''' <summary>
	''' メッセージボックスクラス
	''' </summary>
	Public Class CustomMessageBox
		''' <summary>
		''' 指定されたメッセージコードのメッセージをダイアログ表示する。
		''' </summary>
		''' <param name="argMessage">メッセージ</param>
		''' <returns>ダイアログリザルト</returns>
		Public Shared Function Show(argMessage As ApplicationMessage) As DialogResult
			Return Show(argMessage.MessageCd, argMessage.Params)
		End Function

		''' <summary>
		''' 指定されたメッセージコードのメッセージをダイアログ表示する。
		''' </summary>
		''' <param name="argCode">メッセージコード</param>
		''' <param name="argParams">パラメータ</param>
		''' <returns>ダイアログリザルト</returns>
		Public Shared Function Show(argCode As String, ParamArray argParams As Object()) As DialogResult
			Return Show(argCode, MessageBoxDefaultButton.Button1, argParams)
		End Function

		''' <summary>
		''' 発生した例外をエラーダイアログに表示する。
		''' </summary>
		''' <param name="argException">発生した例外</param>
		Protected Sub Show(argException As Exception)
			' 業務エラーの場合
			If TypeOf argException Is BusinessException Then
				' ダイアログ表示
				CustomMessageBox.Show(DirectCast(argException, BusinessException).ApplicationMessage)
			Else
				' その他の場合
				Dim msgCd As String = "EV001"

				If TypeOf argException Is FileNotFoundException Then
					msgCd = "W"
				ElseIf TypeOf argException Is IOException Then
					msgCd = "EV003"
				End If

				' ダイアログ表示
				CustomMessageBox.Show(msgCd, CommonUtil.GetExceptionMessage(argException))
			End If
		End Sub

		''' <summary>
		''' 指定されたメッセージコードのメッセージをダイアログ表示する。
		''' </summary>
		''' <param name="argCode">メッセージコード</param>
		''' <param name="argDefaultButton">既定のボタン(MessageBoxDefaultButtonの一つ)</param>
		''' <param name="argParams">パラメータ</param>
		''' <returns>ダイアログリザルト</returns>
		Public Shared Function Show(argCode As String, argDefaultButton As MessageBoxDefaultButton, ParamArray argParams As Object()) As DialogResult
			If argCode Is Nothing OrElse argCode.Length < 1 Then
				Return DialogResult.Cancel
			End If

			' キャプション、ボタン、アイコンの設定
			Dim caption As String = "メッセージ"
			Dim buttons As MessageBoxButtons = MessageBoxButtons.OK
			Dim icon As MessageBoxIcon = MessageBoxIcon.None
			Select Case argCode(0)
				Case "E"C
					caption = "エラー"
					icon = MessageBoxIcon.[Error]
					Exit Select
				Case "W"C
					caption = "警告"
					icon = MessageBoxIcon.Warning
					Exit Select
				Case "Q"C
					caption = "確認"
					buttons = MessageBoxButtons.YesNo
					icon = MessageBoxIcon.Question
					Exit Select
				Case "I"C
					icon = MessageBoxIcon.Information
					Exit Select
			End Select

			' メッセージボックス表示
			Dim result As DialogResult = MessageBox.Show(MessageManager.GetMessage(argCode, argParams), caption, buttons, icon, argDefaultButton)

			' フォーカスがファンクションキーの場合に移動する
			Dim form__1 As Form = Form.ActiveForm
			'if (form != null && form.ActiveControl is GrapeCity.Win.Input.FunctionKey)
			'    form.SelectNextControl(form, true, true, true, true);

			Return result
		End Function
	End Class
End Namespace

