
Namespace Common.Forms
	Partial Class MainForm
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.tableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
			Me.label2 = New System.Windows.Forms.Label()
			Me.label1 = New System.Windows.Forms.Label()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.textBox2 = New System.Windows.Forms.TextBox()
			Me.flowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
			Me.button1 = New System.Windows.Forms.Button()
			Me.button2 = New System.Windows.Forms.Button()
			Me.dataGridView1 = New System.Windows.Forms.DataGridView()
			Me.選択 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
			Me.flowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
			Me.button3 = New System.Windows.Forms.Button()
			Me.button4 = New System.Windows.Forms.Button()
			Me.button5 = New System.Windows.Forms.Button()
			Me.button6 = New System.Windows.Forms.Button()
			Me.button7 = New System.Windows.Forms.Button()
			Me.tableLayoutPanel1.SuspendLayout()
			Me.flowLayoutPanel1.SuspendLayout()
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.flowLayoutPanel2.SuspendLayout()
			Me.SuspendLayout()
			' 
			' tableLayoutPanel1
			' 
			Me.tableLayoutPanel1.ColumnCount = 2
			Me.tableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F))
			Me.tableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
			Me.tableLayoutPanel1.Controls.Add(Me.label2, 0, 1)
			Me.tableLayoutPanel1.Controls.Add(Me.label1, 0, 0)
			Me.tableLayoutPanel1.Controls.Add(Me.textBox1, 1, 0)
			Me.tableLayoutPanel1.Controls.Add(Me.textBox2, 1, 1)
			Me.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top
			Me.tableLayoutPanel1.Location = New System.Drawing.Point(4, 4)
			Me.tableLayoutPanel1.Name = "tableLayoutPanel1"
			Me.tableLayoutPanel1.RowCount = 2
			Me.tableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F))
			Me.tableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F))
			Me.tableLayoutPanel1.Size = New System.Drawing.Size(984, 100)
			Me.tableLayoutPanel1.TabIndex = 0
			' 
			' label2
			' 
			Me.label2.Location = New System.Drawing.Point(3, 50)
			Me.label2.Name = "label2"
			Me.label2.Size = New System.Drawing.Size(114, 24)
			Me.label2.TabIndex = 2
			Me.label2.Text = "組織名"
			Me.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
			' 
			' label1
			' 
			Me.label1.Location = New System.Drawing.Point(3, 0)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(114, 24)
			Me.label1.TabIndex = 0
			Me.label1.Text = "組織コード"
			Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
			' 
			' textBox1
			' 
			Me.textBox1.Location = New System.Drawing.Point(123, 3)
			Me.textBox1.Name = "textBox1"
			Me.textBox1.Size = New System.Drawing.Size(100, 19)
			Me.textBox1.TabIndex = 3
			' 
			' textBox2
			' 
			Me.textBox2.Location = New System.Drawing.Point(123, 53)
			Me.textBox2.Name = "textBox2"
			Me.textBox2.Size = New System.Drawing.Size(100, 19)
			Me.textBox2.TabIndex = 4
			' 
			' flowLayoutPanel1
			' 
			Me.flowLayoutPanel1.Controls.Add(Me.button1)
			Me.flowLayoutPanel1.Controls.Add(Me.button2)
			Me.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top
			Me.flowLayoutPanel1.Location = New System.Drawing.Point(4, 104)
			Me.flowLayoutPanel1.Name = "flowLayoutPanel1"
			Me.flowLayoutPanel1.Padding = New System.Windows.Forms.Padding(20, 0, 0, 0)
			Me.flowLayoutPanel1.Size = New System.Drawing.Size(984, 30)
			Me.flowLayoutPanel1.TabIndex = 1
			' 
			' button1
			' 
			Me.button1.Location = New System.Drawing.Point(23, 3)
			Me.button1.Name = "button1"
			Me.button1.Size = New System.Drawing.Size(75, 23)
			Me.button1.TabIndex = 0
			Me.button1.Text = "検索"
			Me.button1.UseVisualStyleBackColor = True
			Me.button1.Click += New System.EventHandler(Me.button1_Click)
			' 
			' button2
			' 
			Me.button2.Location = New System.Drawing.Point(104, 3)
			Me.button2.Name = "button2"
			Me.button2.Size = New System.Drawing.Size(75, 23)
			Me.button2.TabIndex = 1
			Me.button2.Text = "条件クリア"
			Me.button2.UseVisualStyleBackColor = True
			Me.button2.Click += New System.EventHandler(Me.button2_Click)
			' 
			' dataGridView1
			' 
			Me.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.選択})
			Me.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
			Me.dataGridView1.Location = New System.Drawing.Point(4, 134)
			Me.dataGridView1.Name = "dataGridView1"
			Me.dataGridView1.RowTemplate.Height = 21
			Me.dataGridView1.Size = New System.Drawing.Size(984, 444)
			Me.dataGridView1.TabIndex = 2
			' 
			' 選択
			' 
			Me.選択.HeaderText = "選択"
			Me.選択.Name = "選択"
			Me.選択.Width = 40
			' 
			' flowLayoutPanel2
			' 
			Me.flowLayoutPanel2.Controls.Add(Me.button3)
			Me.flowLayoutPanel2.Controls.Add(Me.button4)
			Me.flowLayoutPanel2.Controls.Add(Me.button5)
			Me.flowLayoutPanel2.Controls.Add(Me.button6)
			Me.flowLayoutPanel2.Controls.Add(Me.button7)
			Me.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.flowLayoutPanel2.Location = New System.Drawing.Point(4, 578)
			Me.flowLayoutPanel2.Name = "flowLayoutPanel2"
			Me.flowLayoutPanel2.Padding = New System.Windows.Forms.Padding(20, 0, 0, 0)
			Me.flowLayoutPanel2.Size = New System.Drawing.Size(984, 30)
			Me.flowLayoutPanel2.TabIndex = 3
			' 
			' button3
			' 
			Me.button3.Location = New System.Drawing.Point(23, 3)
			Me.button3.Name = "button3"
			Me.button3.Size = New System.Drawing.Size(75, 23)
			Me.button3.TabIndex = 1
			Me.button3.Text = "新規"
			Me.button3.UseVisualStyleBackColor = True
			Me.button3.Click += New System.EventHandler(Me.button3_Click)
			' 
			' button4
			' 
			Me.button4.Location = New System.Drawing.Point(104, 3)
			Me.button4.Name = "button4"
			Me.button4.Size = New System.Drawing.Size(75, 23)
			Me.button4.TabIndex = 2
			Me.button4.Text = "修正"
			Me.button4.UseVisualStyleBackColor = True
			Me.button4.Click += New System.EventHandler(Me.button3_Click)
			' 
			' button5
			' 
			Me.button5.Location = New System.Drawing.Point(185, 3)
			Me.button5.Name = "button5"
			Me.button5.Size = New System.Drawing.Size(75, 23)
			Me.button5.TabIndex = 3
			Me.button5.Text = "削除"
			Me.button5.UseVisualStyleBackColor = True
			Me.button5.Click += New System.EventHandler(Me.button3_Click)
			' 
			' button6
			' 
			Me.button6.Location = New System.Drawing.Point(266, 3)
			Me.button6.Name = "button6"
			Me.button6.Size = New System.Drawing.Size(75, 23)
			Me.button6.TabIndex = 4
			Me.button6.Text = "参照"
			Me.button6.UseVisualStyleBackColor = True
			Me.button6.Click += New System.EventHandler(Me.button3_Click)
			' 
			' button7
			' 
			Me.button7.Location = New System.Drawing.Point(347, 3)
			Me.button7.Name = "button7"
			Me.button7.Size = New System.Drawing.Size(75, 23)
			Me.button7.TabIndex = 5
			Me.button7.Text = "登録"
			Me.button7.UseVisualStyleBackColor = True
			Me.button7.Click += New System.EventHandler(Me.button7_Click)
			' 
			' MainForm
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 12F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(992, 612)
			Me.Controls.Add(Me.dataGridView1)
			Me.Controls.Add(Me.flowLayoutPanel1)
			Me.Controls.Add(Me.tableLayoutPanel1)
			Me.Controls.Add(Me.flowLayoutPanel2)
			Me.DockAreas = DirectCast((WeifenLuo.WinFormsUI.Docking.DockAreas.Float Or WeifenLuo.WinFormsUI.Docking.DockAreas.Document), WeifenLuo.WinFormsUI.Docking.DockAreas)
			Me.Font = New System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(128))
			Me.FormName = "メイン画面"
			Me.Name = "MainForm"
			Me.Padding = New System.Windows.Forms.Padding(4)
			Me.Text = "MainForm"
			Me.tableLayoutPanel1.ResumeLayout(False)
			Me.tableLayoutPanel1.PerformLayout()
			Me.flowLayoutPanel1.ResumeLayout(False)
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.flowLayoutPanel2.ResumeLayout(False)
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private tableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
		Private flowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
		Private dataGridView1 As System.Windows.Forms.DataGridView
		Private flowLayoutPanel2 As System.Windows.Forms.FlowLayoutPanel
		Private button1 As System.Windows.Forms.Button
		Private button2 As System.Windows.Forms.Button
		Private button3 As System.Windows.Forms.Button
		Private button4 As System.Windows.Forms.Button
		Private button5 As System.Windows.Forms.Button
		Private button6 As System.Windows.Forms.Button
		Private button7 As System.Windows.Forms.Button
		Private label2 As System.Windows.Forms.Label
		Private label1 As System.Windows.Forms.Label
		Private textBox1 As System.Windows.Forms.TextBox
		Private textBox2 As System.Windows.Forms.TextBox
		Private 選択 As System.Windows.Forms.DataGridViewCheckBoxColumn
	End Class
End Namespace

