
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms

Imports Common
Imports Common.Unity

Namespace Common.Forms
	''' <summary>
	''' 詳細画面の基底クラス
	''' </summary>
	Public Partial Class DetailForm
		Inherits BaseForm
		#Region "private変数"
		' 選択されたデータ
		Private m_selectedRow As DataRow
		' 操作モード
		Private m_opeMode As OperationMode
		' 検索結果
		Private m_dataSet As DataSet
		#End Region

		#Region "コンストラクタ"
		''' <summary>
		''' コンストラクタ
		''' </summary>
		Public Sub New()
			InitializeComponent()
		End Sub
		#End Region

		Public Sub SetParam(argSelectedRow As DataRow, argOpeMode As OperationMode)
			' 選択されたデータを記憶
			m_selectedRow = argSelectedRow
			' 操作モードを設定
			m_opeMode = argOpeMode
		End Sub

		#Region "イベントハンドラ"
		''' <summary>
		''' フォームロード
		''' </summary>
		Private Sub DetailForm_Load(sender As Object, e As EventArgs)
			Dim idList = New List(Of SelectId)() From { _
				New SelectId("CMSM組織", "A.組織CD") _
			}

			' 検索パラメータ作成
			Dim paramList = New List(Of SelectParam)()
			Dim p1 As Object = If(m_selectedRow IsNot Nothing, m_selectedRow("組織CD"), "")
			paramList.Add(New SelectParam("組織CD", "= @組織CD", p1))

			' 検索実行
			Dim message As ApplicationMessage
			m_dataSet = CommonService.SelectList(idList, paramList, SelectType.All, message)

			Dim result As DataTable = m_dataSet.Tables(0)

			' 新規の場合
			If m_opeMode = OperationMode.[New] Then
				' 検索結果なしの場合、空行を追加
				If result.Rows.Count = 0 Then
					' 空行を作成
					Dim newRow As DataRow = result.NewRow()
					' 初期値の設定
					newRow("ROWNUMBER") = 0D
					' 空行を追加
					result.Rows.Add(newRow)
					' 状態を初期化
					result.AcceptChanges()
				End If
			' 新規以外の場合、返却メッセージの表示
			ElseIf message IsNot Nothing Then
				CustomMessageBox.Show(message)
			End If

			' 検索結果なしの場合は、画面を閉じる
			If result.Rows.Count = 0 Then
				Close()
				Return
			End If

			Dim idList2 = New List(Of SelectId)() From { _
				New SelectId("CMSM汎用基準値", "基準値CD") _
			}

			' 検索パラメータ作成
			Dim paramList2 = New List(Of SelectParam)() From { _
				New SelectParam("分類CD", "= @分類CD", "M001") _
			}

			' 検索実行
			Dim dataSet = CommonService.SelectList(idList2, paramList2, SelectType.All, message)
			' コンボボックスにDataSourceを設定
			comboBox1.DataSource = dataSet.Tables("CMSM汎用基準値")

			' モードによる画面表示の変更
			Select Case m_opeMode
				Case OperationMode.[New]
					FormName += "　新規"
					Exit Select

				Case OperationMode.Update
					FormName += "　修正"
					' 条件部を操作不可にする
					Protect(tableLayoutPanel1)
					Exit Select

				Case OperationMode.Delete
					FormName += "　削除確認"
					' 全体を操作不可にする
					Protect(tableLayoutPanel1)
					Protect(tableLayoutPanel2)
					' ボタンの名称を変更
					button7.Text = "削除実行"
					Exit Select

				Case OperationMode.View
					FormName += "　参照"
					' 全体を操作不可にする
					Protect(tableLayoutPanel1)
					Protect(tableLayoutPanel2)
					' 登録ボタンを使用不可にする
					button7.Enabled = False
					Exit Select
			End Select

			Text = FormName

			' 検索結果をデータソースに設定
			textBox1.DataBindings.Add("Text", result, "組織CD")
			textBox2.DataBindings.Add("Text", result, "組織名")
			comboBox1.DataBindings.Add("SelectedValue", result, "組織階層区分")
		End Sub

		Public Sub Protect(argControl As Control)
			For Each c As Control In argControl.Controls
				If TypeOf c Is TextBox Then
					Dim t As TextBox = TryCast(c, TextBox)
					t.[ReadOnly] = True
					t.BackColor = SystemColors.Control
				ElseIf TypeOf c Is ComboBox Then
					c.Enabled = False
				End If
			Next
		End Sub

		''' <summary>
		''' 登録ボタン押下
		''' </summary>
		<ShowWaiting> _
		Protected Overridable Sub button7_Click(sender As Object, e As EventArgs)
			' 登録確認OKの場合
			If CustomMessageBox.Show("QV001") = DialogResult.Yes Then
				' 編集の確定
				m_dataSet.Tables(0).Rows(0).EndEdit()

				' 変更データ取得
				Dim updateData As DataSet = m_dataSet.GetChanges()

				' 新規の場合、状態を新規に設定
				If m_opeMode = OperationMode.[New] Then
					updateData.AcceptChanges()

					For Each table As DataTable In updateData.Tables
						For Each row As DataRow In table.Rows
							row.SetAdded()
						Next
					Next
				' 削除の場合、データをコピーして削除データを作成
				ElseIf m_opeMode = OperationMode.Delete Then
					updateData = m_dataSet.Copy()
					For Each table As DataTable In updateData.Tables
						For Each row As DataRow In table.Rows
							row("削除") = "1"
						Next
					Next
				End If

				' データの変更が無い場合はメッセージを表示
				If updateData Is Nothing Then
					CustomMessageBox.Show("WV106")
					Return
				End If

				' 登録実行
				Dim message As ApplicationMessage
				Dim result = CommonService.Update(updateData, message)

				' 修正の場合は更新情報を最新にする
						'SetUpdateParamsWithName(updateData.Rows[0]);
						' 更新者情報を変更
						'SetUpdateInfo(multiRow);
				If m_opeMode = OperationMode.Update Then
				End If

				' 新規、修正の場合は状態を初期化する
				If m_opeMode = OperationMode.[New] OrElse m_opeMode = OperationMode.Update Then
					m_dataSet.AcceptChanges()
				End If

				' メッセージの表示
				If m_opeMode = OperationMode.Delete Then
					' 削除完了メッセージを表示
					If CustomMessageBox.Show("IV004") = DialogResult.OK Then
						Close()
					End If
				Else
					' 登録完了メッセージを表示
					CustomMessageBox.Show("IV003")
				End If

				' フォーカスを入力可能最上位にセット
				If m_opeMode = OperationMode.[New] Then
					textBox1.Focus()
				Else
					textBox2.Focus()
				End If
			End If
		End Sub
		#End Region
	End Class
End Namespace

