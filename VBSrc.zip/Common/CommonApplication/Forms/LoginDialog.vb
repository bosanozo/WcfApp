
Imports System.Security.Principal
Imports System.Threading
Imports System.Windows.Forms

Imports Common.Unity
Imports Common.Service

Namespace Common.Forms
	''' <summary>
	''' ログインダイアログ
	''' </summary>
	Public Partial Class LoginDialog
		Inherits BaseForm
		#Region "private変数"
		Private m_exception As Exception
		Private m_service As IAuthenticationService
		#End Region

		#Region "コンストラクタ"
		''' <summary>
		''' コンストラクタ
		''' </summary>
		''' <param name="argAuthService">認証サービス</param>
		Public Sub New(argAuthService As IAuthenticationService)
			InitializeComponent()
			m_service = argAuthService
		End Sub
		#End Region

		#Region "プロパティ"
		''' <summary>
		''' メッセージ
		''' </summary>
		Public Property Message() As String
			Get
				Return labelMessage.Text
			End Get
			Set
				labelMessage.Text = value
			End Set
		End Property

		''' <summary>
		''' サブメッセージ
		''' </summary>
		Public Property SubMessage() As String
			Get
				Return labelSubMessage.Text
			End Get
			Set
				labelSubMessage.Text = value
			End Set
		End Property

		''' <summary>
		''' ログイン処理で発生した例外
		''' </summary>
		Public ReadOnly Property Exception() As Exception
			Get
				Return m_exception
			End Get
		End Property

		''' <summary>
		''' ユーザＩＤ（入力不可）
		''' </summary>
		''' <remarks>設定された場合、ユーザＩＤ入力欄は ReadOnly に設定されます</remarks>
		Public Property UserIdFixed() As Boolean
			Get
				Return textBoxUserId.[ReadOnly]
			End Get
			Set
				textBoxUserId.[ReadOnly] = value
				textBoxUserId.TabStop = Not value
			End Set
		End Property

		''' <summary>
		''' ユーザＩＤ
		''' </summary>
		Public Property UserId() As String
			Get
				Return textBoxUserId.Text
			End Get
			Set
				textBoxUserId.Text = value
			End Set
		End Property
		#End Region

		#Region "イベントハンドラ"
		''' <summary>
		''' 「ログイン」ボタン　Click
		''' </summary>
		<ShowWaiting> _
		Protected Overridable Sub buttonLogin_Click(sender As Object, e As EventArgs)
			' 必須入力のチェック
			If textBoxUserId.Text.Length = 0 Then
				' メッセージ（詳細）
				SubMessage = labelUserId.Text + "を入力してください。"
				textBoxUserId.Focus()
				Return
			Else
				' メッセージ（詳細）
				SubMessage = String.Empty
			End If

			'Form prevDefaultOwner = AutoWaitingDialogWorker.DefaultOwnerForm;
			Try
				' AutoWaitingDialogWorker.DefaultOwnerForm = this;

				' 画面入力されたユーザの認証を実行
				Dim success As Boolean = m_service.Login(textBoxUserId.Text, textBoxPassword.Text, Nothing, False)
				If success Then
					' ユーザ情報取得
					If InformationManager.UserInfo Is Nothing Then
						InformationManager.UserInfo = CommonService.GetUserInfo()
					End If

					Dim uinfo = InformationManager.UserInfo

					' Principal設定
					Thread.CurrentPrincipal = New GenericPrincipal(New GenericIdentity(uinfo.Id), uinfo.Roles)
					DialogResult = DialogResult.OK
				Else
					SubMessage = labelUserId.Text + "またはパスワードが不正です。"
				End If
			Catch ex As Exception
				m_exception = ex
				DialogResult = DialogResult.Abort
					'AutoWaitingDialogWorker.DefaultOwnerForm = prevDefaultOwner;
			Finally
			End Try
		End Sub

		''' <summary>
		''' コード値の頭０埋めを行う。
		''' </summary>
		Private Sub textBoxUserId_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs)
			If textBoxUserId.Text.Length > 0 Then
				textBoxUserId.Text = textBoxUserId.Text.PadLeft(textBoxUserId.MaxLength, "0"C)
			End If
		End Sub
		#End Region
	End Class
End Namespace

