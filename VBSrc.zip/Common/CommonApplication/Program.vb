
Imports System.Windows.Forms

Imports Microsoft.Practices.Unity

Imports Common.Forms
Imports Common.Unity

Namespace Common
	''' <summary>
	''' エントリポイントクラス
	''' </summary>
	NotInheritable Class Program
		Private Sub New()
		End Sub
		''' <summary>
		''' アプリケーションのメイン エントリ ポイントです。
		''' </summary>
		<STAThread> _
		Private Shared Sub Main()
			Try
				' 共通初期設定
				If Not Initialization.InitialSetting() Then
					Return
				End If

				' UnityでFormを生成
				Dim form = UnityContainerManager.Container.Resolve(Of ContainerForm)()

				' 画面表示
				Application.Run(form)
			Catch ex As Exception
				' 例外処理
				'（集約例外ハンドラに処理させるため、ThreadExceptionイベントを起こす）
				Application.OnThreadException(ex)
			End Try
		End Sub
	End Class
End Namespace

