
Imports System.Linq

Imports System.Configuration
Imports System.ServiceModel
Imports System.ServiceModel.Configuration
Imports System.ServiceModel.Channels

Namespace Common.Wcf
	''' <summary>
	''' WCFサービスユーティリティ
	''' </summary>
	Public Class ServiceUtil
		''' <summary>
		''' 指定されたサービスインターフェースからChannelProxyを作成する。
		''' </summary>
		''' <param name="argType">サービスインターフェース</param>
		''' <returns>ChannelProxy</returns>
		Public Shared Function GetServiceProxy(argType As Type) As Object
			' ServiceContractを取得
			Dim svcAttr = argType.CustomAttributes.[Single](Function(attr) attr.AttributeType = GetType(ServiceContractAttribute))
			Dim argName = svcAttr.NamedArguments.SingleOrDefault(Function(arg) arg.MemberName = "Name")

			' Nameで指定されている場合はNameの値から、指定されていない場合はクラス名からサービス名を取得
			Dim serviceName As String = If(argName.MemberInfo IsNot Nothing, argName.TypedValue.Value.ToString().Substring(1), argType.Name.Substring(1))

			' URI作成
			Dim epAddr = New EndpointAddress(ConfigurationManager.AppSettings("baseAddress") + serviceName & Convert.ToString(".svc"))

			Dim factoryType = GetType(ChannelFactory(Of )).MakeGenericType(argType)
			Dim factory As ChannelFactory = Nothing

			' 構成ファイルにある場合は構成ファイルから生成
			Dim clientSection = TryCast(ConfigurationManager.GetSection("system.serviceModel/client"), ClientSection)
			For i As Integer = 0 To clientSection.Endpoints.Count - 1
				If clientSection.Endpoints(i).Name = serviceName Then
					' Addressが設定されている場合は、設定値を使用する
					Dim createArgs = If(clientSection.Endpoints(i).Address Is Nothing, New Object() {serviceName, epAddr}, New Object() {serviceName})

					' ChannelFactory作成
					factory = DirectCast(Activator.CreateInstance(factoryType, createArgs), ChannelFactory)
					Exit For
				End If
			Next

			' 構成ファイルに無い場合はデフォルトで生成
			If factory Is Nothing Then
				' Binding作成
				Dim binding = New CustomBinding("DefaultBinding")
				' ChannelFactory作成
				factory = DirectCast(Activator.CreateInstance(factoryType, New Object() {binding, epAddr}), ChannelFactory)
			End If

			' エンドポイント・ビヘイビアの追加
			factory.Endpoint.Behaviors.Add(New CustomEndpointBehavior())

			' プロキシを作成して返却
			Return factoryType.GetMethod("CreateChannel", New Type() {}).Invoke(factory, Nothing)
		End Function
	End Class
End Namespace

