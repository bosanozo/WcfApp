
' 【共通部品】
' 
' 作成者: 豆蔵／田中 望
' 改版履歴:
' 2014.7.1, 新規作成

Imports log4net.Core
Imports log4net.Appender

Namespace Common
    ''' <summary>
    ''' VisualStudioデバッグコンソールに出力するためのAppender
    ''' </summary>
    Public Class DebugConsoleAppender
        Inherits AppenderSkeleton
        Protected Overrides Sub Append(evt As LoggingEvent)
            System.Diagnostics.Debug.WriteLine(evt.RenderedMessage)
        End Sub
    End Class
End Namespace

