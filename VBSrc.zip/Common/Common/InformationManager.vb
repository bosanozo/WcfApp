
Imports System.Web

Namespace Common
    ''' <summary>
    ''' ユーザ情報へのアクセスを提供します。
    ''' </summary>
    Public Class InformationManager
        Private Shared s_userInfo As UserInformation = Nothing
        Private Shared s_clientInfo As ClientInformation = Nothing

        ''' <summary>
        ''' ユーザ情報
        ''' </summary>
        Public Shared Property UserInfo() As UserInformation
            Get
                Return If(HttpContext.Current IsNot Nothing, TryCast(HttpContext.Current.Session("UserInformation"), UserInformation), s_userInfo)
            End Get
            Set
                If HttpContext.Current IsNot Nothing Then
                    HttpContext.Current.Session("UserInformation") = value
                Else
                    s_userInfo = value
                End If
            End Set
        End Property

        ''' <summary>
        ''' クライアント情報
        ''' </summary>
        Public Shared Property ClientInfo() As ClientInformation
            Get
                Return If(HttpContext.Current IsNot Nothing, TryCast(HttpContext.Current.Items("ClientInformation"), ClientInformation), s_clientInfo)
            End Get
            Set
                If HttpContext.Current IsNot Nothing Then
                    HttpContext.Current.Items("ClientInformation") = value
                Else
                    s_clientInfo = value
                End If
            End Set
        End Property
    End Class
End Namespace

