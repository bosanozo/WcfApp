
Imports System.Web

Namespace Common
    ''' <summary>
    ''' ユーザ情報を格納するためのクラス
    ''' </summary>
    <Serializable> _
    Public Class ClientInformation
        ''' <summary>画面ID</summary>
        Public Property FormId() As String
            Get
                Return m_FormId
            End Get
            Set
                m_FormId = Value
            End Set
        End Property
        Private m_FormId As String

        ''' <summary>
        ''' ホスト名
        ''' </summary>
        Public ReadOnly Property HostName() As String
            Get
                Return If(HttpContext.Current IsNot Nothing, HttpContext.Current.Request.UserHostAddress, System.Environment.MachineName)
            End Get
        End Property
    End Class
End Namespace

