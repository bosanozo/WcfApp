﻿Imports System.Collections.Generic
Imports System.Data
Imports System.IO
Imports System.Linq
Imports System.Xml.Serialization

Namespace Common
    ''' <summary>
    ''' メッセージソース
    ''' </summary>
    Public Class MessageManager
        Private Shared s_messages As MessagesModel

        ''' <summary>
        ''' メッセージファイル
        ''' </summary>
        Public Shared Property MessageFileDir() As String
            Get
                Return m_MessageFileDir
            End Get
            Set
                m_MessageFileDir = Value
            End Set
        End Property
        Private Shared m_MessageFileDir As String

        ''' <summary>
        ''' メッセージ定義文字列を返す。
        ''' </summary>
        ''' <param name="argMessageCode">メッセージコード</param>
        ''' <param name="argParams">パラメータ</param>
        ''' <returns>メッセージ</returns>
        Public Shared Function GetMessage(argMessageCode As String, ParamArray argParams As Object()) As String
            ' メッセージ定義の読み込み
            If s_messages Is Nothing Then
                s_messages = New MessagesModel()
                s_messages.Message = New List(Of MessageModel)()

                Dim serializer As New XmlSerializer(GetType(MessagesModel))

                Dim files As String() = Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory + Path.DirectorySeparatorChar + MessageFileDir, "Message*.xml")

                For Each file As String In files
                    Dim messages As MessagesModel
                    Using fs As New FileStream(file, FileMode.Open)
                        messages = DirectCast(serializer.Deserialize(fs), MessagesModel)
                    End Using

                    s_messages.Message.AddRange(messages.Message)
                Next
            End If

            ' メッセージ定義の取得
            Dim msg As MessageModel = s_messages.Message.[Single](Function(m) m.Code = argMessageCode)
            Return String.Format(msg.Format, argParams)
        End Function
    End Class
End Namespace
