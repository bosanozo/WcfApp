
' 【共通部品】
' *
' 作成者: 豆蔵／田中 望
' 改版履歴:
' 2014.1.30, 新規作成

Imports System.Runtime.Serialization

Namespace Common
    ''' <summary>
    ''' メッセージデータ
    ''' </summary>
    <Serializable> _
    <DataContract> _
    Public Class ApplicationMessage
        #Region "プロパティ"
        ''' <summary>
        ''' メッセージコード
        ''' </summary>
        <DataMember> _
        Public Property MessageCd() As String
            Get
                Return m_MessageCd
            End Get
            Set
                m_MessageCd = Value
            End Set
        End Property
        Private m_MessageCd As String

        ''' <summary>
        ''' データテーブル名、行番号、フィールドデータ
        ''' </summary>
        <DataMember> _
        Public Property RowField() As RowField
            Get
                Return m_RowField
            End Get
            Set
                m_RowField = Value
            End Set
        End Property
        Private m_RowField As RowField

        ''' <summary>
        ''' パラメータ
        ''' </summary>
        <DataMember> _
        Public Property Params() As Object()
            Get
                Return m_Params
            End Get
            Set
                m_Params = Value
            End Set
        End Property
        Private m_Params As Object()
        #End Region

        #Region "コンストラクタ"
        ''' <summary>
        ''' コンストラクタ
        ''' メッセージデータを生成する。
        ''' </summary>
        ''' <param name="argMsgCode">メッセージコード</param>
        ''' <param name="argParams">パラメータ</param>
        Public Sub New(argMsgCode As String, ParamArray argParams As Object())
            MessageCd = argMsgCode
            Params = argParams
        End Sub

        ''' <summary>
        ''' コンストラクタ（行番号指定）
        ''' メッセージデータを生成する。
        ''' </summary>
        ''' <param name="argMsgCode">メッセージコード</param>
        ''' <param name="argRowField">行番号</param>
        ''' <param name="argParams">パラメータ</param>
        Public Sub New(argMsgCode As String, argRowField As RowField, ParamArray argParams As Object())
            Me.New(argMsgCode, argParams)
            RowField = argRowField
        End Sub
        #End Region

        ''' <summary>
        ''' メッセージ文字列を返す。
        ''' </summary>
        Public Overrides Function ToString() As String
            Return MessageManager.GetMessage(MessageCd, Params)
        End Function
    End Class
End Namespace

