

Namespace Common
    ''' <summary>
    ''' ユーザ情報を格納するためのクラス
    ''' </summary>
    <Serializable> _
    Public Class UserInformation
        ''' <summary>ユーザＩＤ</summary>
        Public Property Id() As String
            Get
                Return m_Id
            End Get
            Set
                m_Id = Value
            End Set
        End Property
        Private m_Id As String

        ''' <summary>ユーザ名</summary>
        Public Property Name() As String
            Get
                Return m_Name
            End Get
            Set
                m_Name = Value
            End Set
        End Property
        Private m_Name As String

        ''' <summary>ロール</summary>
        Public Property Roles() As String()
            Get
                Return m_Roles
            End Get
            Set
                m_Roles = Value
            End Set
        End Property
        Private m_Roles As String()

        ''' <summary>組織コード</summary>
        Public Property SoshikiCd() As String
            Get
                Return m_SoshikiCd
            End Get
            Set
                m_SoshikiCd = Value
            End Set
        End Property
        Private m_SoshikiCd As String

        ''' <summary>組織名</summary>
        Public Property SoshikiName() As String
            Get
                Return m_SoshikiName
            End Get
            Set
                m_SoshikiName = Value
            End Set
        End Property
        Private m_SoshikiName As String

        ''' <summary>組織階層区分</summary>
        Public Property SoshikiKaisoKbn() As String
            Get
                Return m_SoshikiKaisoKbn
            End Get
            Set
                m_SoshikiKaisoKbn = Value
            End Set
        End Property
        Private m_SoshikiKaisoKbn As String
    End Class
End Namespace

