
' 【共通部品】
' *
' 作成者: 豆蔵／田中 望
' 改版履歴:
' 2014.1.30, 新規作成


Namespace Common
    ''' <summary>
    ''' データテーブル名、行番号、フィールドデータ
    ''' </summary>
    <Serializable> _
    Public Class RowField
        #Region "プロパティ"
        ''' <summary>
        ''' データテーブル名
        ''' </summary>
        Public Property DataTableName() As String
            Get
                Return m_DataTableName
            End Get
            Set
                m_DataTableName = Value
            End Set
        End Property
        Private m_DataTableName As String

        ''' <summary>
        ''' 行番号
        ''' </summary>
        Public Property RowNumber() As Integer
            Get
                Return m_RowNumber
            End Get
            Set
                m_RowNumber = Value
            End Set
        End Property
        Private m_RowNumber As Integer

        ''' <summary>
        ''' フィールド名
        ''' </summary>
        Public Property FieldName() As String
            Get
                Return m_FieldName
            End Get
            Set
                m_FieldName = Value
            End Set
        End Property
        Private m_FieldName As String
        #End Region

        #Region "コンストラクタ"
        ''' <summary>
        ''' コンストラクタ
        ''' </summary>
        ''' <param name="argFieldName">フィールド名</param>
        Public Sub New(argFieldName As String)
            Me.New(0, argFieldName)
        End Sub

        ''' <summary>
        ''' コンストラクタ
        ''' </summary>
        ''' <param name="argRowNumber">行番号</param>
        ''' <param name="argFieldName">フィールド名</param>
        Public Sub New(argRowNumber As Integer, Optional argFieldName As String = Nothing)
            Me.New(Nothing, argRowNumber, argFieldName)
        End Sub

        ''' <summary>
        ''' コンストラクタ
        ''' </summary>
        ''' <param name="argDataTableName">データテーブル名</param>
        ''' <param name="argRowNumber">行番号</param>
        ''' <param name="argFieldName">フィールド名</param>
        Public Sub New(argDataTableName As String, argRowNumber As Integer, Optional argFieldName As String = Nothing)
            DataTableName = argDataTableName
            RowNumber = argRowNumber
            FieldName = argFieldName
        End Sub
        #End Region
    End Class
End Namespace

