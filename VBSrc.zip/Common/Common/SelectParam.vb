
' 【共通部品】
' *
' 作成者: 豆蔵／田中 望
' 改版履歴:
' 2014.1.30, 新規作成

Imports System.Collections.Generic
Imports System.Reflection
Imports System.Runtime.Serialization
Imports System.Text.RegularExpressions

Namespace Common
    ''' <summary>
    ''' 検索条件クラス
    ''' </summary>
    <DataContract> _
    Public Class SelectParam
        #Region "プロパティ"
        ''' <summary>項目名</summary>
        <DataMember> _
        Public Property Name() As String
            Get
                Return m_Name
            End Get
            Set
                m_Name = Value
            End Set
        End Property
        Private m_Name As String

        ''' <summary>検索条件SQL</summary>
        <DataMember> _
        Public Property Condtion() As String
            Get
                Return m_Condtion
            End Get
            Set
                m_Condtion = Value
            End Set
        End Property
        Private m_Condtion As String

        ''' <summary>プレースフォルダに設定するFrom値</summary>
        <DataMember> _
        Public Property FromValue() As Object
            Get
                Return m_FromValue
            End Get
            Set
                m_FromValue = Value
            End Set
        End Property
        Private m_FromValue As Object

        ''' <summary>プレースフォルダに設定するTo値</summary>
        <DataMember> _
        Public Property ToValue() As Object
            Get
                Return m_ToValue
            End Get
            Set
                m_ToValue = Value
            End Set
        End Property
        Private m_ToValue As Object

        ''' <summary>左辺項目名(leftcol = @name)</summary>
        <DataMember> _
        Public Property LeftCol() As String
            Get
                Return m_LeftCol
            End Get
            Set
                m_LeftCol = Value
            End Set
        End Property
        Private m_LeftCol As String

        ''' <summary>検索条件を追加する検索ID</summary>
        ''' <remarks>未指定の場合は全テーブルの検索に条件を追加する。</remarks>
        <DataMember> _
        Public Property SelectId() As String
            Get
                Return m_SelectId
            End Get
            Set
                m_SelectId = Value
            End Set
        End Property
        Private m_SelectId As String
        #End Region

        #Region "コンストラクタ"
        ''' <summary>
        ''' コンストラクタ
        ''' </summary>
        ''' <param name="argName">項目名</param>
        ''' <param name="argCondtion">検索条件SQL</param>
        ''' <param name="argFrom">プレースフォルダに設定するFrom値</param>
        ''' <param name="argTo">プレースフォルダに設定するTo値</param>
        Public Sub New(argName As String, argCondtion As String, argFrom As Object, Optional argTo As Object = Nothing)
            Name = argName
            Condtion = argCondtion
            FromValue = argFrom
            ToValue = argTo
        End Sub
        #End Region

        ''' <summary>
        ''' 検索パラメータ作成
        ''' </summary>
        ''' <returns>検索パラメータ</returns>
        Public Shared Function CreateSelectParam(Name As String, Code As String, Params As String, DbCodeCol As String, DbNameCol As String, CodeId As String) As List(Of SelectParam)
            ' 画面の条件を取得
            Dim formParam = New List(Of SelectParam)()

            If Not String.IsNullOrEmpty(Name) Then
                formParam.Add(New SelectParam("Name", "LIKE @Name", (Convert.ToString("%") & Name) + "%"))
            End If

            If Not String.IsNullOrEmpty(Code) Then
                formParam.Add(New SelectParam("Code", "= @Code", Code))
            End If

            ' 検索コード名
            Dim codeCol = Regex.Replace(CodeId, "(From|To)", "")
            Dim nameCol = Regex.Replace(codeCol, "(CD|ID)", "名")

            ' 項目名の置き換え
            For Each p As var In formParam
                If p.Name = "Code" Then
                    p.Name = If(String.IsNullOrEmpty(DbCodeCol), codeCol, DbCodeCol)
                ElseIf p.Name = "Name" Then
                    p.Name = If(String.IsNullOrEmpty(DbNameCol), nameCol, DbNameCol)
                    p.Condtion = "LIKE @" + p.Name
                    p.FromValue = "%" + p.FromValue + "%"
                End If
            Next

            ' 検索パラメータ作成
            Dim param = New List(Of SelectParam)()

            ' 追加パラメータがある場合、追加する
            If Not String.IsNullOrEmpty(Params) Then
                For Each p As String In Params.Split()
                    Dim value As Object

                    ' "#"から始まる場合はUserInfoから設定
                    If p(0) = "#"C Then
                        Dim pi As PropertyInfo = InformationManager.UserInfo.[GetType]().GetProperty(p.Substring(1))
                        value = pi.GetValue(InformationManager.UserInfo, Nothing)
                    Else
                        ' セルの値を取得
                        value = p
                    End If

                    ' パラメータ追加
                    param.Add(New SelectParam(Nothing, Nothing, value))
                Next
            End If

            ' 画面の条件を追加
            param.AddRange(formParam)

            Return param
        End Function
    End Class
End Namespace

