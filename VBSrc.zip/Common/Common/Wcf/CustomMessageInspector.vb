
Imports System.ServiceModel
Imports System.ServiceModel.Channels
Imports System.ServiceModel.Dispatcher

Imports System.Net

Namespace Common.Wcf
    ''' <summary>
    ''' CustomMessageInspector
    ''' </summary>
    Public Class CustomMessageInspector
        Implements IClientMessageInspector
        Implements IDispatchMessageInspector
        ' クッキーコンテナ
        Private Shared ReadOnly s_cookieContainer As New CookieContainer()

        #Region "IClientMessageInspector メンバ"
        ''' <summary>
        ''' リプライ受信時の処理
        ''' </summary>
        ''' <param name="reply">Message</param>
        ''' <param name="correlationState">object</param>
        Public Sub AfterReceiveReply(ByRef reply As Message, correlationState As Object)
            'var aaa = ((HttpResponseMessageProperty)reply.Properties[HttpResponseMessageProperty.Name]).Headers["Set-Cookie"];
        End Sub

        ''' <summary>
        ''' リクエスト送信時の処理
        ''' </summary>
        ''' <param name="request">Message</param>
        ''' <param name="channel">IClientChannel</param>
        ''' <returns></returns>
        Public Function BeforeSendRequest(ByRef request As Message, channel As IClientChannel) As Object
            ' ヘッダ情報の設定
            request.Headers.Add(MessageHeader.CreateHeader("FormId", "ns", InformationManager.ClientInfo.FormId))

            ' クッキーコンテナを設定
            Dim cookieManager = channel.GetProperty(Of IHttpCookieContainerManager)()
            If cookieManager IsNot Nothing Then
                cookieManager.CookieContainer = s_cookieContainer
            End If

            Return Nothing
        End Function
        #End Region

        #Region "IDispatchMessageInspector メンバ"
        ''' <summary>
        ''' リクエスト受信時の処理
        ''' </summary>
        ''' <param name="request">Message</param>
        ''' <param name="channel">IClientChannel</param>
        ''' <param name="instanceContext">InstanceContext</param>
        ''' <returns></returns>
        Public Function AfterReceiveRequest(ByRef request As Message, channel As IClientChannel, instanceContext As InstanceContext) As Object
            ' ヘッダ情報の取得
            If request.Headers.FindHeader("FormId", "ns") > 0 Then
                InformationManager.ClientInfo = New ClientInformation() With { _
                    Key .FormId = request.Headers.GetHeader(Of String)("FormId", "ns") _
                }
            End If

            Return Nothing
        End Function

        ''' <summary>
        ''' リプライ送信時の処理
        ''' </summary>
        ''' <param name="reply">Message</param>
        ''' <param name="correlationState">object</param>
        Public Sub BeforeSendReply(ByRef reply As Message, correlationState As Object)
        End Sub
        #End Region
    End Class
End Namespace

