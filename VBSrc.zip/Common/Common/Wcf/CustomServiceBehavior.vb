
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.ServiceModel
Imports System.ServiceModel.Channels
Imports System.ServiceModel.Configuration
Imports System.ServiceModel.Description
Imports System.ServiceModel.Dispatcher

Namespace Common.Wcf
    ''' <summary>
    ''' CustomServiceBehavior
    ''' </summary>
    Public Class CustomServiceBehavior
        Implements IServiceBehavior
        Private errorHandler As IErrorHandler = New CustomErrorHandler()

        #Region "IServiceBehavior メンバ"
        ''' <summary>
        ''' IServiceBehaviorのメソッド
        ''' </summary>
        ''' <param name="serviceDescription"></param>
        ''' <param name="serviceHostBase"></param>
        ''' <param name="endpoints"></param>
        ''' <param name="bindingParameters"></param>
        Public Sub AddBindingParameters(serviceDescription As ServiceDescription, serviceHostBase As ServiceHostBase, endpoints As System.Collections.ObjectModel.Collection(Of ServiceEndpoint), bindingParameters As BindingParameterCollection)
        End Sub

        ''' <summary>
        ''' エラーハンドラの登録
        ''' </summary>
        ''' <param name="serviceDescription">ServiceDescription</param>
        ''' <param name="serviceHostBase">ServiceHostBase</param>
        Public Sub ApplyDispatchBehavior(serviceDescription As ServiceDescription, serviceHostBase As ServiceHostBase)
            ' エラーハンドラを設定
            For Each dispatcherBase As ChannelDispatcherBase In serviceHostBase.ChannelDispatchers
                Dim dispatcher As ChannelDispatcher = TryCast(dispatcherBase, ChannelDispatcher)
                If dispatcher Is Nothing Then
                    Continue For
                End If

                dispatcher.ErrorHandlers.Add(Me.errorHandler)
            Next
        End Sub

        ''' <summary>
        ''' IServiceBehaviorのメソッド
        ''' </summary>
        ''' <param name="serviceDescription"></param>
        ''' <param name="serviceHostBase"></param>
        Public Sub Validate(serviceDescription As ServiceDescription, serviceHostBase As ServiceHostBase)
        End Sub
        #End Region
    End Class
End Namespace

