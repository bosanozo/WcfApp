
Imports System.Diagnostics
Imports System.ServiceModel
Imports System.ServiceModel.Channels
Imports System.ServiceModel.Dispatcher

Imports log4net

Imports Common.Service

Namespace Common.Wcf
    ''' <summary>
    ''' CustomErrorHandler
    ''' </summary>
    Public Class CustomErrorHandler
        Implements IErrorHandler
        #Region "ロガーフィールド"
        Private m_logger As ILog
        #End Region

        #Region "コンストラクタ"
        ''' <summary>
        ''' コンストラクタ
        ''' </summary>
        Public Sub New()
            ' ロガーを取得
            m_logger = LogManager.GetLogger(Me.[GetType]())
        End Sub
        #End Region

        #Region "IErrorHandler メンバ"
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="error">Exception</param>
        ''' <returns></returns>
        Public Function HandleError([error] As Exception) As Boolean
            ' ログ出力
            If TypeOf [error] Is BusinessException Then
                m_logger.[Error](DirectCast([error], BusinessException).ApplicationMessage, [error].InnerException)
            Else
                m_logger.[Error]([error])
            End If

            ' イベントログへの出力実施！
            '
'            string errorType = error.GetType().Name;
'            string errorMessage = error.Message;
'            string errorStackTrace = error.StackTrace;
'            string evtSrc = "app";
'
'            if (!EventLog.SourceExists(evtSrc)) EventLog.CreateEventSource(evtSrc, "");
'
'            EventLog.WriteEntry(evtSrc, string.Format("{0}.{1}() {2}\r\n{3}",
'                error.TargetSite.DeclaringType.Name, error.TargetSite.Name,
'                errorMessage, error.ToString()), EventLogEntryType.Error);
'            

            Return False
        End Function

        ''' <summary>
        ''' BusinessExceptionの場合FaultException<ApplicationMessage>を生成する。
        ''' </summary>
        ''' <param name="error">Exception</param>
        ''' <param name="version">MessageVersion</param>
        ''' <param name="message">Message</param>
        Public Sub ProvideFault([error] As Exception, version As MessageVersion, ByRef message__1 As Message)
            If TypeOf [error] Is BusinessException Then
                Dim reason As New FaultReason("サーバ側でアプリケーションエラーが発生しました。")
                Dim fe As New FaultException(Of ApplicationMessage)(DirectCast([error], BusinessException).ApplicationMessage, reason)
                Dim fault As MessageFault = fe.CreateMessageFault()
                message__1 = Message.CreateMessage(version, fault, fe.Action)
            End If
        End Sub
        #End Region
    End Class
End Namespace

