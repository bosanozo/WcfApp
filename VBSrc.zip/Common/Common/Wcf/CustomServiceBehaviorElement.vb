
Imports System.ServiceModel.Configuration

Namespace Common.Wcf
    ''' <summary>
    ''' app.configに登録できるようにするためのエレメント
    ''' </summary>
    Public Class CustomServiceBehaviorElement
        Inherits BehaviorExtensionElement
        Public Overrides ReadOnly Property BehaviorType() As Type
            Get
                Return GetType(CustomServiceBehavior)
            End Get
        End Property

        Protected Overrides Function CreateBehavior() As Object
            Return New CustomServiceBehavior()
        End Function
    End Class
End Namespace

