
Imports System.ServiceModel.Channels
Imports System.ServiceModel.Description
Imports System.ServiceModel.Dispatcher

Namespace Common.Wcf
    ''' <summary>
    ''' CustomEndpointBehavior
    ''' </summary>
    Public Class CustomEndpointBehavior
        Implements IEndpointBehavior
        #Region "IEndpointBehavior メンバ"
        ''' <summary>
        ''' IEndpointBehaviorのメソッド
        ''' </summary>
        ''' <param name="endpoint"></param>
        ''' <param name="bindingParameters"></param>
        Public Sub AddBindingParameters(endpoint As ServiceEndpoint, bindingParameters As BindingParameterCollection)
        End Sub

        ''' <summary>
        ''' クライアント側メッセージインスペクタの登録
        ''' </summary>
        ''' <param name="endpoint"></param>
        ''' <param name="clientRuntime"></param>
        Public Sub ApplyClientBehavior(endpoint As ServiceEndpoint, clientRuntime As ClientRuntime)
            clientRuntime.MessageInspectors.Add(New CustomMessageInspector())
        End Sub

        ''' <summary>
        ''' サーバ側メッセージインスペクタの登録
        ''' </summary>
        ''' <param name="endpoint"></param>
        ''' <param name="endpointDispatcher"></param>
        Public Sub ApplyDispatchBehavior(endpoint As ServiceEndpoint, endpointDispatcher As EndpointDispatcher)
            endpointDispatcher.DispatchRuntime.MessageInspectors.Add(New CustomMessageInspector())
        End Sub

        ''' <summary>
        ''' IEndpointBehaviorのメソッド
        ''' </summary>
        ''' <param name="endpoint"></param>
        Public Sub Validate(endpoint As ServiceEndpoint)
        End Sub
        #End Region
    End Class
End Namespace

