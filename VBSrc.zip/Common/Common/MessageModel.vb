﻿Imports System.Collections.Generic
Imports System.Xml.Serialization

Namespace Common
    ''' <summary>
    ''' メッセージ定義ルート
    ''' </summary>
    <XmlRoot("DocumentElement")> _
    Public Class MessagesModel
        <XmlElement> _
        Public Property Message() As List(Of MessageModel)
            Get
                Return m_Message
            End Get
            Set
                m_Message = Value
            End Set
        End Property
        Private m_Message As List(Of MessageModel)
    End Class

    ''' <summary>
    ''' メッセージ定義
    ''' </summary>
    Public Class MessageModel
        <XmlElement> _
        Public Property Code() As String
            Get
                Return m_Code
            End Get
            Set
                m_Code = Value
            End Set
        End Property
        Private m_Code As String

        <XmlElement> _
        Public Property Format() As String
            Get
                Return m_Format
            End Get
            Set
                m_Format = Value
            End Set
        End Property
        Private m_Format As String
    End Class
End Namespace
