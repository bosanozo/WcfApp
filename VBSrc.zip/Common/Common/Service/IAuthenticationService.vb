
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.ServiceModel

Namespace Common.Service
    ''' <summary>
    ''' 認証サービスのインターフェース
    ''' </summary>
    <ServiceContract([Namespace] := "http://asp.net/ApplicationServices/v200")> _
    Public Interface IAuthenticationService
        Inherits IBaseService
        <OperationContract(Action := "http://asp.net/ApplicationServices/v200/AuthenticationService/ValidateUser")> _
        Function ValidateUser(username As String, password As String, customCredential As String) As Boolean

        <OperationContract(Action := "http://asp.net/ApplicationServices/v200/AuthenticationService/Login")> _
        Function Login(username As String, password As String, customCredential As String, isPersistent As Boolean) As Boolean

        <OperationContract(Action := "http://asp.net/ApplicationServices/v200/AuthenticationService/IsLoggedIn")> _
        Function IsLoggedIn() As Boolean

        <OperationContract(Action := "http://asp.net/ApplicationServices/v200/AuthenticationService/Logout")> _
        Sub Logout()
    End Interface
End Namespace

