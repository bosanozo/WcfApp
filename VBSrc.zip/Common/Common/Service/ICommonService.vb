
Imports System.Collections.Generic
Imports System.Data
Imports System.ServiceModel

Imports Common

Namespace Common.Service
    ''' <summary>
    ''' 共通処理サービスインターフェース
    ''' </summary>
    <ServiceContract> _
    Public Interface ICommonService
        Inherits IBaseService
        ''' <summary>
        ''' ユーザ情報を取得する。
        ''' </summary>
        ''' <returns>ユーザ情報</returns>
        <OperationContract> _
        Function GetUserInfo() As UserInformation

        ''' <summary>
        ''' 指定された検索IDのSQL、パラメータで検索を実行する。
        ''' </summary>
        ''' <param name="argSelectId">検索ID</param>
        ''' <param name="argParams">検索パラメータ</param>
        ''' <returns>検索結果</returns>
        <OperationContract> _
        <FaultContract(GetType(ApplicationMessage))> _
        Function [Select](argSelectId As String, ParamArray argParams As Object()) As DataSet

        ''' <summary>
        ''' 指定された検索IDのSQLファイルからSELECT文を作成し、検索を実行する。
        ''' </summary>
        ''' <param name="argSelectIdList">検索IDリスト</param>
        ''' <param name="argParamList">検索条件リスト</param>
        ''' <param name="argSelectType">検索種別</param>
        ''' <param name="argMessage">返却メッセージ</param>
        ''' <returns>検索結果</returns>
        <OperationContract> _
        <FaultContract(GetType(ApplicationMessage))> _
        Function SelectList(argSelectIdList As List(Of SelectId), argParamList As List(Of SelectParam), argSelectType As SelectType, ByRef argMessage As ApplicationMessage) As DataSet

        ''' <summary>
        ''' データセットのデータを登録する。
        ''' </summary>
        ''' <param name="argDataSet">登録データ</param>
        ''' <param name="argMessage">返却メッセージ</param>
        ''' <returns>処理件数</returns>
        <OperationContract> _
        <FaultContract(GetType(ApplicationMessage))> _
        Function Update(argDataSet As DataSet, ByRef argMessage As ApplicationMessage) As Integer
    End Interface
End Namespace

