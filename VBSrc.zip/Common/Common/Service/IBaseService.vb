
Namespace Common.Service
    ''' <summary>
    ''' サービス基底インターフェース
    ''' </summary>
    Public Interface IBaseService
    End Interface
End Namespace

