
' 【共通部品】
' *
' 作成者: 豆蔵／田中 望
' 改版履歴:
' 2014.1.30, 新規作成

Imports System.Collections.Generic
Imports System.Data
Imports System.Text
Imports System.Text.RegularExpressions

Namespace Common
    ''' <summary>
    ''' ユーティリティクラス
    ''' </summary>
    Public NotInheritable Class CommonUtil
        Private Sub New()
        End Sub
        ''' <summary>
        ''' ダイアログに表示するメッセージを返す。
        ''' </summary>
        ''' <param name="argExDetail">ExceptionDetail</param>
        ''' <returns>ダイアログに表示するメッセージ</returns>
        Public Shared Function GetExceptionMessage(argEx As Exception) As String
            Return argEx.Message + (If(argEx.InnerException IsNot Nothing, System.Environment.NewLine + GetExceptionMessage(argEx.InnerException), Nothing))
        End Function

        ''' <summary>
        ''' DataRowから行番号を取得する。
        ''' </summary>
        ''' <param name="argDataRow">DataRow</param>
        ''' <returns>行番号(行番号なしの場合は0を返す。)</returns>
        Public Shared Function GetRowNumber(argDataRow As DataRow) As Integer
            Dim rowNumber As Integer = 0
            ' 行番号を取得
            If argDataRow.Table.Columns.Contains("ROWNUMBER") Then
                Dim version As DataRowVersion = If(argDataRow.RowState = DataRowState.Deleted, DataRowVersion.Original, DataRowVersion.Current)
                rowNumber = Convert.ToInt32(argDataRow("ROWNUMBER", version))
            End If

            Return rowNumber
        End Function

        ''' <summary>
        ''' DataColumnに対応した型の値を取得する。
        ''' </summary>
        ''' <param name="dcol">DataColumn</param>
        ''' <param name="value">値の文字列</param>
        ''' <returns>DataColumnに対応した型の値</returns>
        Public Shared Function GetDataColumnVal(dcol As DataColumn, value As String) As Object
            If value.Length = 0 Then
                Return DBNull.Value
            End If

            Dim result As Object

            ' 型に応じて、値を比較し、DataTableに値を設定する
            Select Case dcol.DataType.Name
                Case "bool", "Boolean"
                    ' できてない
                    result = value = "true"
                    'Convert.ToBoolean(value);
                    Exit Select

                Case "decimal"
                    result = Convert.ToDecimal(value)
                    Exit Select

                Case "int32", "Byte"
                    result = Convert.ToInt32(value)
                    Exit Select

                Case "DateTime"
                    result = Convert.ToDateTime(value)
                    Exit Select
                Case Else

                    result = value
                    Exit Select
            End Select

            Return result
        End Function
    End Class
End Namespace

