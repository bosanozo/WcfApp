
' 【共通部品】
' *
' 作成者: 豆蔵／田中 望
' 改版履歴:
' 2015.1.26, 新規作成

Imports System.Runtime.Serialization

Namespace Common
    ''' <summary>
    ''' 検索IDクラス
    ''' </summary>
    <DataContract> _
    Public Class SelectId
        #Region "プロパティ"
        ''' <summary>検索ID</summary>
        <DataMember> _
        Public Property Id() As String
            Get
                Return m_Id
            End Get
            Set
                m_Id = Value
            End Set
        End Property
        Private m_Id As String

        ''' <summary>ソート条件</summary>
        <DataMember> _
        Public Property Order() As String
            Get
                Return m_Order
            End Get
            Set
                m_Order = Value
            End Set
        End Property
        Private m_Order As String
        #End Region

        #Region "コンストラクタ"
        ''' <summary>
        ''' コンストラクタ
        ''' </summary>
        ''' <param name="argId">検索ID</param>
        ''' <param name="argOrder">ソート条件</param>
        Public Sub New(argId As String, argOrder As String)
            Id = argId
            Order = argOrder
        End Sub
        #End Region

    End Class
End Namespace

