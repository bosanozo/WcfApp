
' 【共通部品】
' *
' 作成者: 豆蔵／田中 望
' 改版履歴:
' 2014.1.30, 新規作成

Imports System.Collections.Generic
Imports System.Data
Imports System.Runtime.Serialization
Imports System.Text

Namespace Common
    ''' <summary>
    ''' 業務アプリケーション例外クラス
    ''' </summary>
    <Serializable> _
    Public Class BusinessException
        Inherits Exception
        #Region "プロパティ"
        ''' <summary>
        ''' メッセージ
        ''' </summary>
        Public Property ApplicationMessage() As ApplicationMessage
            Get
                Return DirectCast(Data("Message"), ApplicationMessage)
            End Get
            Set
                Data.Add("Message", value)
            End Set
        End Property
        #End Region

        #Region "コンストラクタ"
        ' 親クラスから引き継いだコンストラクタ
        Public Sub New()
        End Sub
        Public Sub New(argMessage As String)
            MyBase.New(argMessage)
        End Sub
        Public Sub New(argMessage As String, argInnerException As Exception)
            MyBase.New(argMessage, argInnerException)
        End Sub
        Public Sub New(argSerializationInfo As SerializationInfo, argStreamingContext As StreamingContext)
            MyBase.New(argSerializationInfo, argStreamingContext)
        End Sub

        ''' <summary>
        ''' コンストラクタ
        ''' </summary>
        ''' <param name="argMessage">メッセージデータ</param>
        Public Sub New(argMessage As ApplicationMessage)
            ApplicationMessage = argMessage
        End Sub

        ''' <summary>
        ''' コンストラクタ
        ''' </summary>
        ''' <param name="argMessage">メッセージデータ</param>
        ''' <param name="argInnerException">例外発生の元となった例外</param>
        Public Sub New(argMessage As ApplicationMessage, argInnerException As Exception)
            MyBase.New(argInnerException.Message, argInnerException)
            ApplicationMessage = argMessage
        End Sub
        #End Region

        ''' <summary>
        ''' メッセージ文字列を返す。
        ''' </summary>
        Public Overrides Function ToString() As String
            If ApplicationMessage IsNot Nothing Then
                ' 全メッセージ文字列を連結
                Dim builder As New StringBuilder(ApplicationMessage.ToString())

                ' メッセージがエラー以外の場合は簡略化する
                If ApplicationMessage.MessageCd.Length >= 1 AndAlso ApplicationMessage.MessageCd(0) <> "E"C Then
                    If InnerException IsNot Nothing Then
                        builder.AppendLine().Append(InnerException.[GetType]().FullName).Append(": ").Append(InnerException.Message)
                    End If
                Else
                    builder.AppendLine().Append(MyBase.ToString())
                End If

                Return builder.ToString()
            Else
                Return MyBase.ToString()
            End If
        End Function
    End Class
End Namespace

